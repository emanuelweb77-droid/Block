# Block Blast Guía 1.1.2 — versión para probar

## Instalar desde tu GitHub actual
1. Reemplaza el archivo BlockBlastGuia.zip de la raíz de tu repositorio por este ZIP, con el mismo nombre. No hace falta extraerlo en GitHub.
2. Confirma la carga. Tu workflow actual Build APK lo extrae y ejecuta assembleDebug.
3. Abre Actions, espera la marca verde y descarga el artefacto BlockBlastGuia-apk.
4. Extrae app-debug.apk en el celular e instálalo. Si Android rechaza actualizar por una firma diferente, guarda la versión anterior antes de desinstalarla.

## Uso
Comparte TODA la pantalla, abre el juego y deja el menú fuera del tablero y de las piezas. Arrastra el título para moverlo; un toque lo pliega.

- Auto calibrar: lee cuatro capturas coincidentes; la barra avanza con esas lecturas. No dibuja cuadrícula amarilla. Si no encuentra el tablero, informa el fallo y puedes repetir.
- Auto marcar: muestra «Marcando…» y SOLO la próxima pieza. El círculo bajo la bandeja indica qué pieza usar. Colócala; espera dos capturas estables (mínimo 120 ms, más el procesamiento del teléfono) para ver la siguiente recomendación. Otro toque pausa las marcas.
- Detener en la notificación cierra el servicio.

## Cambios
- Eliminadas las marcas de movimientos futuros que dependían de borrar filas todavía ocupadas.
- La referencia del color vacío se aprende al calibrar y no se cambia por el color mayoritario después de cada jugada.
- Lectura conservadora: las casillas cuyo color no coincide se consideran ocupadas.
- Dos lecturas concordantes durante al menos 120 ms antes de recalcular; no se borran las marcas ante cada lectura pasajera.
- Verificación del tablero más reciente antes de mostrar una solución calculada.
- Muestreo central de las piezas; rechazo de lecturas ambiguas; las piezas diagonales también son válidas.
- Liberación de bitmaps y recursos de captura; cancelación de resultados obsoletos al pausar o recalibrar.
- Cálculo con búsqueda limitada para evitar bloqueos prolongados. Es una recomendación heurística, no una garantía de la mejor jugada global.

## Comprobaciones y límites
El código Kotlin completo compila contra Android API 34. Pasaron nueve pruebas JUnit: pieza diagonal, referencia violeta saturada, rechazo de referencia inexistente, solapamientos y límites, borrado simultáneo, movimientos que requieren limpiar antes, planes legales en 25 tableros, rendimiento y estabilidad temporal.
No se ejecutó la app en un Android real y no se generó un APK aquí. El workflow de GitHub realiza el empaquetado. La captura, superposición, precisión del detector y calibración requieren una prueba en el teléfono.

Esta calibración está preparada para el tablero oscuro habitual, con al menos cuatro casillas vacías visibles; rechaza referencias claras/desconocidas. Mantén la orientación vertical y recalibra al cambiar el diseño. Si no detecta bien, envía una grabación que muestre tablero, piezas y menú.

Para correr las pruebas en GitHub, el comando de compilación puede ser:
    gradle testDebugUnitTest assembleDebug

## Corrección 1.1.1
La versión anterior rechazaba el fondo violeta porque su saturación era mayor que 0,72. Se eliminó esa condición: el color vacío se sigue aprendiendo una vez y comprobando en varias capturas.
Se reprodujo el fallo con la captura 59969.jpg del usuario. Tras corregirlo, el análisis del código de producción detecta el tablero, las 64 casillas y las tres piezas (rectángulo 2×3, cuadrado 3×3 y L de cinco). La prueba usa un adaptador de imagen JVM para leer los píxeles; no prueba MediaProjection ni el menú en Android.

## Corrección 1.1.2
- Eliminado el rechazo de las piezas diagonales, causa reproducida del mensaje «esperando imagen clara» en 59973.jpg y en el final de 59972.mp4.
- Intervalo de captura/procesamiento de 300 a 120 ms y estabilidad mínima de 600 a 120 ms (dos capturas reales). Esto no garantiza una latencia final de 120 ms en el teléfono.
- Verificación final de la imagen trasladada al hilo de trabajo para no bloquear el menú.
- Optimización del último nivel del cálculo de jugadas: elimina ordenación y evaluación duplicadas.
- Mensajes con altura limitada y botón activo más corto para que el menú no crezca hacia el tablero.
- Si falla la lectura durante 700 ms, se retira una marca antigua en vez de mantenerla 2,5 segundos.
- Código compilado; nueve pruebas JUnit superadas. La foto detecta las dos casillas diagonales. Veinte fotogramas del video se procesan sin el error anterior; los últimos muestran las tres piezas correctas. Son pruebas de los algoritmos con píxeles mediante adaptador JVM, no una ejecución de la app en Android.
