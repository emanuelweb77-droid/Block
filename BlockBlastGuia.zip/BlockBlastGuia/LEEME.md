# Block Blast Guía 1.1.3 — versión para probar

## Generar el APK
Reemplaza BlockBlastGuia.zip en la raíz de tu GitHub por este ZIP, con el mismo nombre y sin extraerlo. Tu workflow Build APK lo extrae y compila. Descarga el artefacto BlockBlastGuia-apk cuando finalice, extrae app-debug.apk e instálalo.
Si Android rechaza una actualización por firma diferente, conserva el APK anterior antes de desinstalarlo.

## Uso
1. Inicia la guía y comparte TODA la pantalla.
2. Abre el juego. Mueve el menú fuera del tablero y de las piezas arrastrando el título; un toque lo pliega.
3. Usa Auto calibrar con el tablero quieto y al menos cuatro casillas vacías. La barra corresponde a cuatro capturas concordantes; no se dibuja cuadrícula amarilla.
4. Activa Auto marcar. Se marca solo la próxima pieza y su destino. Al colocarla, espera que termine la animación para recibir otra recomendación.
5. Auto marcar otra vez pausa. El botón × cierra la guía, retira sus ventanas, detiene la captura y finaliza su actividad si aún existe. Android puede conservar un proceso inactivo en caché: no queda capturando pantalla.

## Correcciones de 1.1.3
- Se quitó un filtro que confundía bloques azul grisáceo del tema verde con sombras, dejando piezas incompletas.
- El fondo se reajusta usando muestras de casillas previamente vacías, confirmadas en varias capturas. No se elige el color mayoritario de los bloques ocupados. Un destello aislado no cambia el modelo.
- Cuando se confirma otro fondo se invalida la recomendación antigua y se vuelve a leer el tablero.
- Las marcas conservan el color detectado. Ya no se aumenta artificialmente la saturación.
- Se ignoran objetos demasiado pequeños o grandes para una pieza de la bandeja, aunque los efectos animados todavía pueden producir lecturas inciertas.
- Se añadió × para cerrar sin ampliar el menú con otra fila.

## Correcciones conservadas
Piezas diagonales válidas; lectura estable antes de calcular; recomendación de una sola pieza; comprobación actualizada antes de dibujar; verificación en segundo plano; espera mínima de 120 ms entre dos capturas concordantes; cálculo acotado para evitar bloqueos; liberación de imágenes y recursos; cancelación de resultados al pausar o cerrar.

## Verificación
- Compilación Kotlin contra API 34.
- Doce pruebas JUnit: legalidad, límites, limpieza simultánea, diagonales, estabilidad, rendimiento y adaptación de fondo, incluyendo vuelta al tema anterior y rechazo de destellos aislados.
- Regresión del detector con dos capturas del tema violeta y dos fotogramas quietos del nuevo tema verde: tablero y formas esperados.
- Revisión de 72 fotogramas de 60001.mp4 con adaptador de píxeles JVM. Los tramos quietos que antes rechazaban las piezas grisáceas se leen correctamente. No se considera que las animaciones deban producir jugadas.

## Límites
No se ejecutó la app en un teléfono/emulador Android y no se generó un APK aquí. Las pruebas de imágenes ejecutan los algoritmos con un adaptador JVM, no MediaProjection ni WindowManager.
El video no contiene el instante del cambio de tema: esa transición se probó con muestras simuladas en las pruebas unitarias. La captura, cierre de ventanas y adaptación automática requieren prueba en el celular.
El ajuste automático necesita varias casillas previamente vacías como referencia. Si cambian las dimensiones/posición de la mesa, usa Auto calibrar otra vez. No se garantiza compatibilidad con todos los temas ni jugada óptima global.

Para ejecutar las pruebas al compilar en GitHub, puede usarse:
    gradle testDebugUnitTest assembleDebug
