package com.kuvi.blockblastguide

/** Updates only from previously empty cells, never from the majority of occupied blocks. */
class ThemeTracker {
    var reference:Int?=null
        private set
    private var candidate:Int?=null
    private var count=0
    private var since=0L
    fun reset(color:Int) { reference=color; candidate=null; count=0; since=0 }
    fun observe(emptySamples:List<Int>,now:Long):Boolean {
        val current=reference ?: return false
        if(emptySamples.size<4) return true // No safe anchors to relearn: keep the verified reference.
        val next=EmptyColor.consensus(emptySamples) ?: run {
            candidate=null; count=0
            return emptySamples.count { EmptyColor.distance(it,current)<=30 } >= (emptySamples.size+1)/2
        }
        val change=EmptyColor.distance(next,current)
        if(change<=12) { candidate=null; count=0; return true }
        if(candidate==null || EmptyColor.distance(candidate!!,next)>12) {
            candidate=next; count=1; since=now; return false
        }
        count++
        val large=change>45
        if(count >= (if(large) 3 else 2) && now-since >= (if(large) 240 else 120)) {
            reference=next; candidate=null; count=0; return true
        }
        return false
    }
}
