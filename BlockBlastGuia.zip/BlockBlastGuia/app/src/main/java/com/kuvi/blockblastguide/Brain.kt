package com.kuvi.blockblastguide

import android.graphics.*

class Reading(val board: IntArray, val pieces: List<Vision.Piece>, val sig: String)

object Vision {
    class Piece(val g: Array<IntArray>, val box: RectF, val color: Int)

    fun shape(g: Array<IntArray>): List<Pair<Int, Int>>? {
        val o = ArrayList<Pair<Int, Int>>()
        for (r in 0..4) for (c in 0..4) if (g[r][c] == 1) o.add(Pair(r, c))
        if (o.isEmpty()) return null
        val mr = o.minOf { it.first }; val mc = o.minOf { it.second }
        return o.map { Pair(it.first - mr, it.second - mc) }
    }

    fun read(bm: Bitmap, g: FloatArray, reference: Int): Reading {
        require(g.size == 4 && g[0] >= 0 && g[1] >= 0 && g[2] <= bm.width && g[3] <= bm.height)
        val board = board(bm, g, reference)
        val ps = pieces(bm, g)
        val sig = reference.toString() + ":" + board.joinToString(",") + "|" + ps.joinToString(";") { p -> "${(p.box.centerX() * 3 / bm.width).toInt()}:" + (shape(p.g)?.joinToString("") { "${it.first}${it.second}" } ?: "-") }
        return Reading(board, ps, sig)
    }

    fun colorDistance(a: Int, b: Int): Double = EmptyColor.distance(a,b)
    // Learn a dark empty-cell reference ONCE, never from the majority after every move.
    // Do not reject saturated dark backgrounds: the standard violet board has S ~ 0.8.
    // Unsupported/light boards still fail calibration instead of guessing empty cells.
    fun emptyReference(bm: Bitmap, g: FloatArray): Int? {
        val cw=(g[2]-g[0])/8; val ch=(g[3]-g[1])/8
        val colors=(0..63).map { i -> bm.getPixel((g[0]+(i%8+.5f)*cw).toInt(),(g[1]+(i/8+.5f)*ch).toInt()) }
        return EmptyColor.choose(colors)
    }
    fun emptyAnchors(bm:Bitmap,g:FloatArray,previous:IntArray):List<Int> {
        val cw=(g[2]-g[0])/8; val ch=(g[3]-g[1])/8
        return (0..63).filter { i -> previous[i/8] and (1 shl (i%8)) == 0 }.map { i ->
            bm.getPixel((g[0]+(i%8+.5f)*cw).toInt().coerceIn(0,bm.width-1),
                (g[1]+(i/8+.5f)*ch).toInt().coerceIn(0,bm.height-1))
        }
    }
    fun board(bm: Bitmap,g:FloatArray,reference:Int):IntArray {
        val cw=(g[2]-g[0])/8; val ch=(g[3]-g[1])/8
        return IntArray(8) { r ->
            var mask=0
            for(c in 0..7) {
                var occupied=false
                for(dy in -1..1) for(dx in -1..1) {
                    val x=(g[0]+(c+.5f+dx*.12f)*cw).toInt().coerceIn(0,bm.width-1)
                    val y=(g[1]+(r+.5f+dy*.12f)*ch).toInt().coerceIn(0,bm.height-1)
                    if(colorDistance(bm.getPixel(x,y),reference)>27) occupied=true
                }
                if(occupied) mask=mask or (1 shl c)
            }; mask
        }
    }

    // La bandeja se lee solo entre el tablero y 4 casillas más abajo (así no entran los anuncios).
    fun pieces(bm: Bitmap, g: FloatArray): List<Piece> {
        val cw = (g[2] - g[0]) / 8; val ch = (g[3] - g[1]) / 8
        val rx = maxOf(0, (g[0] - cw).toInt()); val rx2 = minOf(bm.width, (g[2] + cw).toInt())
        val ry = (g[3] + .3f * ch).toInt(); val ry2 = minOf(bm.height, (g[3] + 4f * ch).toInt())
        val w = rx2 - rx; val h = ry2 - ry
        if (h < 20 || w < 20) return emptyList()
        val px = IntArray(w * h); bm.getPixels(px, 0, w, rx, ry, w, h)
        // fondo de cada fila = mediana de esa fila (aguanta degradados y colores oscuros)
        val bgr = IntArray(h); val bgg = IntArray(h); val bgb = IntArray(h)
        val cnt = (w + 5) / 6
        val ar = IntArray(cnt); val ag = IntArray(cnt); val ab = IntArray(cnt)
        for (y in 0 until h) {
            var i = 0; var x = 0
            while (x < w) { val c = px[y * w + x]; ar[i] = Color.red(c); ag[i] = Color.green(c); ab[i] = Color.blue(c); i++; x += 6 }
            ar.sort(0, i); ag.sort(0, i); ab.sort(0, i)
            bgr[y] = ar[i / 2]; bgg[y] = ag[i / 2]; bgb[y] = ab[i / 2]
        }
        fun fg(x: Int, y: Int): Boolean {
            val c = px[y * w + x]
            val r = Color.red(c); val gr = Color.green(c); val b = Color.blue(c)
            val a = r - bgr[y]; val e = gr - bgg[y]; val d = b - bgb[y]
            if (a * a + e * e + d * d <= 900) return false
            // A dark, desaturated block can be foreground on a bright background.
            // Do not remove it merely because all three channels are darker.
            return true
        }
        val cc = IntArray(w)
        for (y in 0 until h step 2) for (x in 0 until w) if (fg(x, y)) cc[x]++
        val runs = ArrayList<IntArray>(); var s = -1; var e = 0; var gap = 0
        for (x in 0..w) {
            if (x < w && cc[x] >= 3) { if (s < 0) s = x; e = x; gap = 0 }
            else if (s >= 0) { gap++; if (gap > cw * .25f || x == w) { runs.add(intArrayOf(s, e)); s = -1 } }
        }
        class It(val x: Int, val y: Int, val w: Int, val h: Int)
        var items: List<It> = runs.filter { it[1] - it[0] >= cw * .30f && it[1] - it[0] <= cw * 2.8f }.mapNotNull { r ->
            var t = -1; var u = 0
            for (y in 0 until h) {
                var n = 0; var x = r[0]
                while (x <= r[1]) { if (fg(x, y)) n++; x += 2 }
                if (n >= 2) { if (t < 0) t = y; u = y }
            }
            if (t < 0) null else It(r[0], t, r[1] - r[0] + 1, u - t + 1)
        }.filter { it.h >= cw * .30f && it.h <= cw * 2.8f }
        require(items.size <= 3) { "Bandeja tapada o en movimiento" }
        items = items.sortedBy { it.x }
        if (items.isEmpty()) return emptyList()
        // tamaño de bloque en la bandeja: en este juego mide ~0.445 de una casilla del tablero.
        val dims = items.flatMap { listOf(it.w, it.h) }
        fun fit(lo: Float, hi: Float): Pair<Float, Double> {
            var bq = lo; var be = 1e9; var q = lo
            while (q <= hi + 1e-4f) {
                var er = 0.0
                for (d in dims) { val n = d / (q * cw); val r = Math.round(n); er += if (r < 1 || r > 5) 1.0 else Math.abs(n - r.toDouble()) }
                er += Math.abs(q - .445f) * 0.5
                if (er < be) { be = er; bq = q }
                q += .004f
            }
            return Pair(bq, be)
        }
        var best = fit(.38f, .52f)
        if (best.second > .12 * dims.size) best = fit(.3f, .65f)
        require(best.second <= .2 * dims.size) { "Tamaño de pieza incierto" }
        val sz = best.first * cw
        return items.map { o ->
            val nc = Math.round(o.w / sz).coerceIn(1, 5); val nr = Math.round(o.h / sz).coerceIn(1, 5)
            val gr = Array(5) { IntArray(5) }
            for (r in 0 until nr) for (c in 0 until nc) {
                val x = (o.x + (c + .5f) * o.w / nc).toInt().coerceIn(0, w - 1)
                val y = (o.y + (r + .5f) * o.h / nr).toInt().coerceIn(0, h - 1)
                var votes=0
                val offset=(sz*.12f).toInt().coerceAtLeast(1)
                for(dy in -1..1) for(dx in -1..1) if(fg((x+dx*offset).coerceIn(0,w-1),(y+dy*offset).coerceIn(0,h-1))) votes++
                require(votes==0 || votes>=8) { "Pieza animada o parcialmente tapada" }
                gr[r][c] = if(votes>=8) 1 else 0
            }
            var colr = Color.GRAY
            loop@ for (r in 0 until nr) for (c in 0 until nc) if (gr[r][c] == 1) {
                val x = (o.x + (c + .5f) * o.w / nc).toInt().coerceIn(1, w - 2)
                val y = (o.y + (r + .5f) * o.h / nr).toInt().coerceIn(1, h - 2)
                colr = px[y * w + x]; break@loop
            }
            // Block Blast includes diagonal pieces: edge connectivity is NOT required.
            require(shape(gr) != null) { "Pieza vacía" }
            Piece(gr, RectF((rx + o.x).toFloat(), (ry + o.y).toFloat(), (rx + o.x + o.w).toFloat(), (ry + o.y + o.h).toFloat()), colr)
        }
    }
}

// Encuentra solo el tablero 8x8 buscando las líneas de la cuadrícula (espaciadas igual).
object Autocal {
    fun find(bm: Bitmap): FloatArray? {
        val W = bm.width; val H = bm.height
        val px = IntArray(W * H); bm.getPixels(px, 0, W, 0, 0, W, H)
        val S = DoubleArray(W); val T = DoubleArray(H); val d = 5
        fun ch(c: Int, k: Int) = when (k) { 0 -> Color.red(c); 1 -> Color.green(c); else -> Color.blue(c) }
        var y = d
        while (y < H - d) {
            var x = d
            while (x < W - d) {
                val c = px[y * W + x]; val l = px[y * W + x - d]; val r = px[y * W + x + d]
                val u = px[(y - d) * W + x]; val b = px[(y + d) * W + x]
                var sx = 0; var sy = 0
                for (k in 0..2) { sx += Math.abs(2 * ch(c, k) - ch(l, k) - ch(r, k)); sy += Math.abs(2 * ch(c, k) - ch(u, k) - ch(b, k)) }
                S[x] += sx.toDouble(); T[y] += sy.toDouble()
                x += 2
            }
            y += 2
        }
        fun mx(A: DoubleArray, i: Int): Double { var m = 0.0; for (j in maxOf(0, i - 2)..minOf(A.size - 1, i + 2)) if (A[j] > m) m = A[j]; return m }
        val Sm = DoubleArray(W) { mx(S, it) }; val Tm = DoubleArray(H) { mx(T, it) }
        var best = -1.0; var res: FloatArray? = null
        var cw = W * .09
        while (cw <= W * .12) {
            var bx = -1.0; var x0b = 0; var x0 = 0
            while (x0 + 8 * cw < W - 1) { var s = 0.0; for (k in 0..8) s += Sm[(x0 + k * cw).toInt()]; if (s > bx) { bx = s; x0b = x0 }; x0++ }
            var by = -1.0; var y0b = 0; var y0 = (H * .12).toInt()
            while (y0 + 8 * cw < H * .82) { var s = 0.0; for (k in 0..8) s += Tm[(y0 + k * cw).toInt()]; if (s > by) { by = s; y0b = y0 }; y0++ }
            if (bx + by > best) { best = bx + by; res = floatArrayOf(x0b.toFloat(), y0b.toFloat(), (x0b + 8 * cw).toFloat(), (y0b + 8 * cw).toFloat()) }
            cw += .5
        }
        val base = 9 * Sm.average() + 9 * Tm.average()
        return if (base <= 0.0 || !base.isFinite() || best / base < 2.6) null else res   // sin tablero ~1.9; con tablero (claro u oscuro) 3.2 a 7
    }
}
