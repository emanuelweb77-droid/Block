package com.kuvi.blockblastguide

import android.graphics.*

val COLS = intArrayOf(0xFFFF5A4F.toInt(), 0xFFFFC43D.toInt(), 0xFF3DDCFF.toInt())

object Vision {
    class Piece(val g: Array<IntArray>, val box: RectF, val color: Int)

    fun lum(c: Int) = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)

    fun shape(g: Array<IntArray>): List<Pair<Int, Int>>? {
        val o = ArrayList<Pair<Int, Int>>()
        for (r in 0..4) for (c in 0..4) if (g[r][c] == 1) o.add(Pair(r, c))
        if (o.isEmpty()) return null
        val mr = o.minOf { it.first }; val mc = o.minOf { it.second }
        return o.map { Pair(it.first - mr, it.second - mc) }
    }

    // g = [x0, y0, x1, y1] del tablero. Devuelve 8 filas como máscaras de bits.
    fun board(bm: Bitmap, g: FloatArray): IntArray {
        val cw = (g[2] - g[0]) / 8; val ch = (g[3] - g[1]) / 8
        val col = Array(64) { DoubleArray(3) }
        for (r in 0..7) for (c in 0..7) {
            val cx = (g[0] + (c + .5f) * cw).toInt().coerceIn(5, bm.width - 6)
            val cy = (g[1] + (r + .5f) * ch).toInt().coerceIn(5, bm.height - 6)
            for (dy in -4..4 step 4) for (dx in -4..4 step 4) {
                val p = bm.getPixel(cx + dx, cy + dy)
                col[r * 8 + c][0] += Color.red(p) / 9.0
                col[r * 8 + c][1] += Color.green(p) / 9.0
                col[r * 8 + c][2] += Color.blue(p) / 9.0
            }
        }
        fun dist(a: DoubleArray, b: DoubleArray) = Math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]))
        // casilla vacía = el color más repetido del tablero (sirve con fondo claro u oscuro)
        var ref = col[0]; var bestN = -1
        for (i in 0..63) { var n = 0; for (j in 0..63) if (dist(col[i], col[j]) < 25) n++; if (n > bestN) { bestN = n; ref = col[i] } }
        return IntArray(8) { r -> var m = 0; for (c in 0..7) if (dist(col[r * 8 + c], ref) > 45) m = m or (1 shl c); m }
    }

    fun pieces(bm: Bitmap, g: FloatArray): List<Piece> {
        val cw = (g[2] - g[0]) / 8; val ch = (g[3] - g[1]) / 8
        val rx = maxOf(0, (g[0] - cw).toInt()); val rx2 = minOf(bm.width, (g[2] + cw).toInt())
        val ry = (g[3] + .3f * ch).toInt(); val ry2 = minOf(bm.height, (g[3] + 6.5f * ch).toInt())
        val w = rx2 - rx; val h = ry2 - ry
        if (h < 20 || w < 20) return emptyList()
        val px = IntArray(w * h); bm.getPixels(px, 0, w, rx, ry, w, h)
        fun med(f: (Int) -> Int): Int { val a = ArrayList<Int>(); var i = 0; while (i < px.size) { a.add(f(px[i])); i += 16 }; a.sort(); return a[a.size / 2] }
        val br = med { Color.red(it) }; val bg = med { Color.green(it) }; val bb = med { Color.blue(it) }
        fun fg(x: Int, y: Int): Boolean {
            val c = px[y * w + x]
            val a = Color.red(c) - br; val b = Color.green(c) - bg; val d = Color.blue(c) - bb
            if (a * a + b * b + d * d <= 3600) return false
            // las sombras de las piezas son el fondo oscurecido: no cuentan
            val q1 = Color.red(c).toFloat() / maxOf(br, 1); val q2 = Color.green(c).toFloat() / maxOf(bg, 1); val q3 = Color.blue(c).toFloat() / maxOf(bb, 1)
            val hi = maxOf(q1, maxOf(q2, q3)); val lo = minOf(q1, minOf(q2, q3))
            return !(hi - lo < .25f && (q1 + q2 + q3) / 3 < 1f)
        }
        val cc = IntArray(w)
        for (y in 0 until h step 2) for (x in 0 until w) if (fg(x, y)) cc[x]++
        val runs = ArrayList<IntArray>(); var s = -1; var e = 0; var gap = 0
        for (x in 0..w) {
            if (x < w && cc[x] >= 3) { if (s < 0) s = x; e = x; gap = 0 }
            else if (s >= 0) { gap++; if (gap > cw * .25f || x == w) { runs.add(intArrayOf(s, e)); s = -1 } }
        }
        class It(val x: Int, val y: Int, val w: Int, val h: Int)
        var items: List<It> = runs.filter { it[1] - it[0] >= cw * .15f && it[1] - it[0] <= cw * 5.3f }.mapNotNull { r ->
            var t = -1; var u = 0
            for (y in 0 until h) {
                var n = 0; var x = r[0]
                while (x <= r[1]) { if (fg(x, y)) n++; x += 2 }
                if (n >= 2) { if (t < 0) t = y; u = y }
            }
            if (t < 0) null else It(r[0], t, r[1] - r[0] + 1, u - t + 1)
        }.filter { it.h >= cw * .15f && it.h <= cw * 5.3f }
        items = items.sortedByDescending { it.w * it.h }.take(3).sortedBy { it.x }
        if (items.isEmpty()) return emptyList()
        // tamaño de bloque en la bandeja: en este juego mide ~0.445 de una casilla del tablero.
        // Se busca cerca de ese valor para no confundir un 3x3 con un 2x2.
        val dims = items.flatMap { listOf(it.w, it.h) }
        fun fit(lo: Float, hi: Float): Pair<Float, Double> {
            var bq = lo; var be = 1e9; var q = lo
            while (q <= hi + 1e-4f) {
                var er = 0.0
                for (d in dims) { val n = d / (q * cw); val r = Math.round(n); er += if (r < 1 || r > 5) 1.0 else Math.abs(n - r.toDouble()) }
                er += Math.abs(q - .445f) * 0.5
                if (er < be) { be = er; bq = q }
                q += .004f
            }
            return Pair(bq, be)
        }
        var best = fit(.38f, .52f)
        if (best.second > .12 * dims.size) best = fit(.3f, .65f)
        val sz = best.first * cw
        return items.map { o ->
            val nc = Math.round(o.w / sz).coerceIn(1, 5); val nr = Math.round(o.h / sz).coerceIn(1, 5)
            val gr = Array(5) { IntArray(5) }
            for (r in 0 until nr) for (c in 0 until nc) {
                val x = (o.x + (c + .5f) * o.w / nc).toInt().coerceIn(0, w - 1)
                val y = (o.y + (r + .5f) * o.h / nr).toInt().coerceIn(0, h - 1)
                gr[r][c] = if (fg(x, y)) 1 else 0
            }
            var colr = Color.GRAY
            loop@ for (r in 0 until nr) for (c in 0 until nc) if (gr[r][c] == 1) {
                val x = (o.x + (c + .5f) * o.w / nc).toInt().coerceIn(1, w - 2)
                val y = (o.y + (r + .5f) * o.h / nr).toInt().coerceIn(1, h - 2)
                colr = px[y * w + x]; break@loop
            }
            Piece(gr, RectF((rx + o.x).toFloat(), (ry + o.y).toFloat(), (rx + o.x + o.w).toFloat(), (ry + o.y + o.h).toFloat()), colr)
        }
    }
}

object Solver {
    val PC = IntArray(256) { Integer.bitCount(it) }
    class P(val m: IntArray, val h: Int, val w: Int)

    fun prep(cells: List<Pair<Int, Int>>): P {
        val h = cells.maxOf { it.first } + 1; val w = cells.maxOf { it.second } + 1
        val m = IntArray(h)
        for ((r, c) in cells) m[r] = m[r] or (1 shl c)
        return P(m, h, w)
    }

    fun put(B: IntArray, p: P, r: Int, c: Int): Pair<IntArray, Int>? {
        val n = B.copyOf()
        for (i in 0 until p.h) { val mk = p.m[i] shl c; if ((n[r + i] and mk) != 0) return null; n[r + i] = n[r + i] or mk }
        var cm = 255
        for (i in 0..7) cm = cm and n[i]
        val fr = BooleanArray(8) { n[it] == 255 }
        var k = 0
        for (i in 0..7) { if (fr[i]) k++; n[i] = if (fr[i]) 0 else (n[i] and cm.inv() and 255) }
        k += PC[cm]
        return Pair(n, k)
    }

    fun ev(B: IntArray, k: Int): Int {
        var e = 0; var iso = 0; var tr = 0
        for (r in 0..7) {
            val v = B[r]; val E = v.inv() and 255
            e += 8 - PC[v]
            iso += PC[E and ((v shl 1) or 1) and 255 and ((v shr 1) or 128) and (if (r > 0) B[r - 1] else 255) and (if (r < 7) B[r + 1] else 255)]
            tr += PC[(v xor (v shr 1)) and 127]
            if (r < 7) tr += PC[v xor B[r + 1]]
        }
        return k * 40 + e * 3 - iso * 20 - tr * 2
    }

    // Devuelve pasos [indicePieza, fila, columna, líneasLimpiadas] en el orden a jugar.
    fun solve(B: IntArray, list: List<P>): List<IntArray> {
        var best = Int.MIN_VALUE; var bm = listOf<IntArray>()
        fun go(b: IntArray, rem: List<Int>, mv: List<IntArray>, k: Int) {
            var any = false
            for (i in rem) {
                val p = list[i]
                for (r in 0..8 - p.h) for (c in 0..8 - p.w) {
                    val o = put(b, p, r, c) ?: continue
                    any = true
                    go(o.first, rem.filter { it != i }, mv + intArrayOf(i, r, c, o.second), k + o.second)
                }
            }
            if (!any) { val s = mv.size * 1000 + ev(b, k); if (s > best) { best = s; bm = mv } }
        }
        go(B, list.indices.toList(), listOf(), 0)
        return bm
    }
}
