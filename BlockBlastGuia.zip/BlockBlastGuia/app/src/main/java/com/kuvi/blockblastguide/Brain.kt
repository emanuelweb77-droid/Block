package com.kuvi.blockblastguide

import android.graphics.*

class Reading(val board: IntArray, val pieces: List<Vision.Piece>, val sig: String)

object Vision {
    class Piece(val g: Array<IntArray>, val box: RectF, val color: Int)

    fun shape(g: Array<IntArray>): List<Pair<Int, Int>>? {
        val o = ArrayList<Pair<Int, Int>>()
        for (r in 0..4) for (c in 0..4) if (g[r][c] == 1) o.add(Pair(r, c))
        if (o.isEmpty()) return null
        val mr = o.minOf { it.first }; val mc = o.minOf { it.second }
        return o.map { Pair(it.first - mr, it.second - mc) }
    }

    fun read(bm: Bitmap, g: FloatArray): Reading {
        val board = board(bm, g)
        val ps = pieces(bm, g)
        val sig = board.joinToString(",") + "|" + ps.joinToString(";") { p -> shape(p.g)?.joinToString("") { "${it.first}${it.second}" } ?: "-" }
        return Reading(board, ps, sig)
    }

    // g = [x0, y0, x1, y1] del tablero. Devuelve 8 filas como máscaras de bits.
    // Cada casilla se juzga con 9 puntos (lejos de los bordes, donde dibujamos las marcas).
    fun board(bm: Bitmap, g: FloatArray): IntArray {
        val cw = (g[2] - g[0]) / 8; val ch = (g[3] - g[1]) / 8
        val off = (cw * .12f).toInt().coerceAtLeast(4)
        val smp = Array(64) { IntArray(9) }
        val col = Array(64) { DoubleArray(3) }
        for (r in 0..7) for (c in 0..7) {
            val cx = (g[0] + (c + .5f) * cw).toInt(); val cy = (g[1] + (r + .5f) * ch).toInt()
            var n = 0
            for (dy in -1..1) for (dx in -1..1) {
                val p = bm.getPixel((cx + dx * off).coerceIn(0, bm.width - 1), (cy + dy * off).coerceIn(0, bm.height - 1))
                smp[r * 8 + c][n++] = p
                col[r * 8 + c][0] += Color.red(p) / 9.0
                col[r * 8 + c][1] += Color.green(p) / 9.0
                col[r * 8 + c][2] += Color.blue(p) / 9.0
            }
        }
        fun dist(a: DoubleArray, b: DoubleArray) = Math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]))
        // casilla vacía = el color más repetido del tablero (sirve con fondo claro u oscuro)
        var ref = col[0]; var bestN = -1
        for (i in 0..63) { var n = 0; for (j in 0..63) if (dist(col[i], col[j]) < 25) n++; if (n > bestN) { bestN = n; ref = col[i] } }
        return IntArray(8) { r ->
            var m = 0
            for (c in 0..7) {
                var k = 0
                for (p in smp[r * 8 + c]) {
                    val a = Color.red(p) - ref[0]; val b = Color.green(p) - ref[1]; val d = Color.blue(p) - ref[2]
                    if (Math.sqrt(a * a + b * b + d * d) > 35) k++
                }
                if (k >= 5) m = m or (1 shl c)
            }
            m
        }
    }

    // La bandeja se lee solo entre el tablero y 4 casillas más abajo (así no entran los anuncios).
    fun pieces(bm: Bitmap, g: FloatArray): List<Piece> {
        val cw = (g[2] - g[0]) / 8; val ch = (g[3] - g[1]) / 8
        val rx = maxOf(0, (g[0] - cw).toInt()); val rx2 = minOf(bm.width, (g[2] + cw).toInt())
        val ry = (g[3] + .3f * ch).toInt(); val ry2 = minOf(bm.height, (g[3] + 4f * ch).toInt())
        val w = rx2 - rx; val h = ry2 - ry
        if (h < 20 || w < 20) return emptyList()
        val px = IntArray(w * h); bm.getPixels(px, 0, w, rx, ry, w, h)
        // fondo de cada fila = mediana de esa fila (aguanta degradados y colores oscuros)
        val bgr = IntArray(h); val bgg = IntArray(h); val bgb = IntArray(h)
        val cnt = (w + 5) / 6
        val ar = IntArray(cnt); val ag = IntArray(cnt); val ab = IntArray(cnt)
        for (y in 0 until h) {
            var i = 0; var x = 0
            while (x < w) { val c = px[y * w + x]; ar[i] = Color.red(c); ag[i] = Color.green(c); ab[i] = Color.blue(c); i++; x += 6 }
            ar.sort(0, i); ag.sort(0, i); ab.sort(0, i)
            bgr[y] = ar[i / 2]; bgg[y] = ag[i / 2]; bgb[y] = ab[i / 2]
        }
        fun fg(x: Int, y: Int): Boolean {
            val c = px[y * w + x]
            val r = Color.red(c); val gr = Color.green(c); val b = Color.blue(c)
            val a = r - bgr[y]; val e = gr - bgg[y]; val d = b - bgb[y]
            if (a * a + e * e + d * d <= 900) return false
            // las sombras son el fondo oscurecido: no cuentan como pieza
            val q1 = r.toFloat() / maxOf(bgr[y], 1); val q2 = gr.toFloat() / maxOf(bgg[y], 1); val q3 = b.toFloat() / maxOf(bgb[y], 1)
            val hi = maxOf(q1, maxOf(q2, q3)); val lo = minOf(q1, minOf(q2, q3))
            return !(hi - lo < .25f && (q1 + q2 + q3) / 3 < 1f)
        }
        val cc = IntArray(w)
        for (y in 0 until h step 2) for (x in 0 until w) if (fg(x, y)) cc[x]++
        val runs = ArrayList<IntArray>(); var s = -1; var e = 0; var gap = 0
        for (x in 0..w) {
            if (x < w && cc[x] >= 3) { if (s < 0) s = x; e = x; gap = 0 }
            else if (s >= 0) { gap++; if (gap > cw * .25f || x == w) { runs.add(intArrayOf(s, e)); s = -1 } }
        }
        class It(val x: Int, val y: Int, val w: Int, val h: Int)
        var items: List<It> = runs.filter { it[1] - it[0] >= cw * .15f && it[1] - it[0] <= cw * 5.3f }.mapNotNull { r ->
            var t = -1; var u = 0
            for (y in 0 until h) {
                var n = 0; var x = r[0]
                while (x <= r[1]) { if (fg(x, y)) n++; x += 2 }
                if (n >= 2) { if (t < 0) t = y; u = y }
            }
            if (t < 0) null else It(r[0], t, r[1] - r[0] + 1, u - t + 1)
        }.filter { it.h >= cw * .15f && it.h <= cw * 5.3f }
        items = items.sortedByDescending { it.w * it.h }.take(3).sortedBy { it.x }
        if (items.isEmpty()) return emptyList()
        // tamaño de bloque en la bandeja: en este juego mide ~0.445 de una casilla del tablero.
        val dims = items.flatMap { listOf(it.w, it.h) }
        fun fit(lo: Float, hi: Float): Pair<Float, Double> {
            var bq = lo; var be = 1e9; var q = lo
            while (q <= hi + 1e-4f) {
                var er = 0.0
                for (d in dims) { val n = d / (q * cw); val r = Math.round(n); er += if (r < 1 || r > 5) 1.0 else Math.abs(n - r.toDouble()) }
                er += Math.abs(q - .445f) * 0.5
                if (er < be) { be = er; bq = q }
                q += .004f
            }
            return Pair(bq, be)
        }
        var best = fit(.38f, .52f)
        if (best.second > .12 * dims.size) best = fit(.3f, .65f)
        val sz = best.first * cw
        return items.map { o ->
            val nc = Math.round(o.w / sz).coerceIn(1, 5); val nr = Math.round(o.h / sz).coerceIn(1, 5)
            val gr = Array(5) { IntArray(5) }
            for (r in 0 until nr) for (c in 0 until nc) {
                val x = (o.x + (c + .5f) * o.w / nc).toInt().coerceIn(0, w - 1)
                val y = (o.y + (r + .5f) * o.h / nr).toInt().coerceIn(0, h - 1)
                gr[r][c] = if (fg(x, y)) 1 else 0
            }
            var colr = Color.GRAY
            loop@ for (r in 0 until nr) for (c in 0 until nc) if (gr[r][c] == 1) {
                val x = (o.x + (c + .5f) * o.w / nc).toInt().coerceIn(1, w - 2)
                val y = (o.y + (r + .5f) * o.h / nr).toInt().coerceIn(1, h - 2)
                colr = px[y * w + x]; break@loop
            }
            Piece(gr, RectF((rx + o.x).toFloat(), (ry + o.y).toFloat(), (rx + o.x + o.w).toFloat(), (ry + o.y + o.h).toFloat()), colr)
        }
    }
}

object Solver {
    val PC = IntArray(256) { Integer.bitCount(it) }
    class P(val m: IntArray, val h: Int, val w: Int)

    fun prep(cells: List<Pair<Int, Int>>): P {
        val h = cells.maxOf { it.first } + 1; val w = cells.maxOf { it.second } + 1
        val m = IntArray(h)
        for ((r, c) in cells) m[r] = m[r] or (1 shl c)
        return P(m, h, w)
    }

    fun put(B: IntArray, p: P, r: Int, c: Int): Pair<IntArray, Int>? {
        val n = B.copyOf()
        for (i in 0 until p.h) { val mk = p.m[i] shl c; if ((n[r + i] and mk) != 0) return null; n[r + i] = n[r + i] or mk }
        var cm = 255
        for (i in 0..7) cm = cm and n[i]
        val fr = BooleanArray(8) { n[it] == 255 }
        var k = 0
        for (i in 0..7) { if (fr[i]) k++; n[i] = if (fr[i]) 0 else (n[i] and cm.inv() and 255) }
        k += PC[cm]
        return Pair(n, k)
    }

    private fun free(B: IntArray, r: Int) = B[r].inv() and 255

    // Valora el tablero final: líneas limpiadas, espacio libre, huecos tapados, orden y "movilidad"
    // (cuántos lugares quedan para piezas grandes como 3x3, 2x2 y barras de 5).
    fun ev(B: IntArray, k: Int, kq: Int): Int {
        var e = 0; var hole = 0; var iso = 0; var tr = 0
        for (r in 0..7) {
            val v = B[r]; val E = v.inv() and 255
            e += 8 - PC[v]
            val up = if (r > 0) B[r - 1] else 255; val dn = if (r < 7) B[r + 1] else 255
            val lf = ((v shl 1) or 1) and 255; val rt = (v shr 1) or 128
            iso += PC[E and lf and rt and up and dn]
            hole += PC[E and ((lf and rt) or (lf and up) or (lf and dn) or (rt and up) or (rt and dn) or (up and dn))]
            tr += PC[(v xor (v shr 1)) and 127]
            if (r < 7) tr += PC[v xor B[r + 1]]
        }
        var n2 = 0; var n3 = 0; var h5 = 0; var v5 = 0
        for (r in 0..7) {
            val f = free(B, r)
            h5 += PC[f and (f shr 1) and (f shr 2) and (f shr 3) and (f shr 4)]
            if (r < 7) { val f2 = f and free(B, r + 1); n2 += PC[f2 and (f2 shr 1)] }
            if (r < 6) { val f3 = f and free(B, r + 1) and free(B, r + 2); n3 += PC[f3 and (f3 shr 1) and (f3 shr 2)] }
            if (r < 4) v5 += PC[f and free(B, r + 1) and free(B, r + 2) and free(B, r + 3) and free(B, r + 4)]
        }
        val mob = minOf(n2, 10) * 2 + minOf(n3, 6) * 4 + minOf(h5, 5) * 2 + minOf(v5, 5) * 2
        return k * 60 + kq * 30 + e * 2 - iso * 30 - hole * 6 - tr * 3 + mob
    }

    // Devuelve pasos [indicePieza, fila, columna, líneasLimpiadas] en el orden a jugar.
    fun solve(B: IntArray, list: List<P>): List<IntArray> {
        var best = Int.MIN_VALUE; var bm = listOf<IntArray>()
        fun go(b: IntArray, rem: List<Int>, mv: List<IntArray>, k: Int, kq: Int) {
            var any = false
            for (i in rem) {
                val p = list[i]
                for (r in 0..8 - p.h) for (c in 0..8 - p.w) {
                    val o = put(b, p, r, c) ?: continue
                    any = true
                    go(o.first, rem.filter { it != i }, mv + intArrayOf(i, r, c, o.second), k + o.second, kq + o.second * o.second)
                }
            }
            if (!any) { val s = mv.size * 100000 + ev(b, k, kq); if (s > best) { best = s; bm = mv } }
        }
        go(B, list.indices.toList(), listOf(), 0, 0)
        return bm
    }
}

// Encuentra solo el tablero 8x8 buscando las líneas de la cuadrícula (espaciadas igual).
object Autocal {
    fun find(bm: Bitmap): FloatArray? {
        val W = bm.width; val H = bm.height
        val px = IntArray(W * H); bm.getPixels(px, 0, W, 0, 0, W, H)
        val S = DoubleArray(W); val T = DoubleArray(H); val d = 5
        fun ch(c: Int, k: Int) = when (k) { 0 -> Color.red(c); 1 -> Color.green(c); else -> Color.blue(c) }
        var y = d
        while (y < H - d) {
            var x = d
            while (x < W - d) {
                val c = px[y * W + x]; val l = px[y * W + x - d]; val r = px[y * W + x + d]
                val u = px[(y - d) * W + x]; val b = px[(y + d) * W + x]
                var sx = 0; var sy = 0
                for (k in 0..2) { sx += Math.abs(2 * ch(c, k) - ch(l, k) - ch(r, k)); sy += Math.abs(2 * ch(c, k) - ch(u, k) - ch(b, k)) }
                S[x] += sx.toDouble(); T[y] += sy.toDouble()
                x += 2
            }
            y += 2
        }
        fun mx(A: DoubleArray, i: Int): Double { var m = 0.0; for (j in maxOf(0, i - 2)..minOf(A.size - 1, i + 2)) if (A[j] > m) m = A[j]; return m }
        val Sm = DoubleArray(W) { mx(S, it) }; val Tm = DoubleArray(H) { mx(T, it) }
        var best = -1.0; var res: FloatArray? = null
        var cw = W * .09
        while (cw <= W * .12) {
            var bx = -1.0; var x0b = 0; var x0 = 0
            while (x0 + 8 * cw < W - 1) { var s = 0.0; for (k in 0..8) s += Sm[(x0 + k * cw).toInt()]; if (s > bx) { bx = s; x0b = x0 }; x0++ }
            var by = -1.0; var y0b = 0; var y0 = 0
            while (y0 + 8 * cw < H - 1) { var s = 0.0; for (k in 0..8) s += Tm[(y0 + k * cw).toInt()]; if (s > by) { by = s; y0b = y0 }; y0++ }
            if (bx + by > best) { best = bx + by; res = floatArrayOf(x0b.toFloat(), y0b.toFloat(), (x0b + 8 * cw).toFloat(), (y0b + 8 * cw).toFloat()) }
            cw += .5
        }
        val base = 9 * Sm.average() + 9 * Tm.average()
        return if (best / base < 2.6) null else res   // sin tablero ~1.9; con tablero (claro u oscuro) 3.2 a 7
    }
}
