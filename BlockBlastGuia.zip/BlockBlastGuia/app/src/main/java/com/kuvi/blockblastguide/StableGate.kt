package com.kuvi.blockblastguide

/** Called only with distinct captured frames, never repeatedly with the same bitmap. */
class StableGate {
    private var candidate: String? = null
    private var count = 0
    private var since = 0L
    fun reset() { candidate=null; count=0; since=0 }
    fun offer(signature:String, now:Long):Boolean {
        if(candidate!=signature) { candidate=signature; count=1; since=now; return false }
        count++
        return count>=2 && now-since>=120
    }
}
