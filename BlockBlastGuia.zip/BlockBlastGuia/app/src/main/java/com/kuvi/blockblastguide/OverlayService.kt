package com.kuvi.blockblastguide

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.*

class Step(val cells: List<RectF>, val box: RectF, val n: Int, val col: Int, val tray: PointF)

// Las marcas se dibujan lejos del centro de las casillas y fuera de la zona donde se leen las piezas,
// así nunca ensucian la lectura de la pantalla.
class Marks(c: Context) : View(c) {
    var steps = listOf<Step>()
    var grid: FloatArray? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK }
    private fun badge(cv: Canvas, x: Float, y: Float, n: Int, col: Int, rad: Float) {
        p.style = Paint.Style.FILL; p.color = col; cv.drawCircle(x, y, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = rad * .18f; p.color = Color.WHITE; cv.drawCircle(x, y, rad, p)
        t.textSize = rad * 1.15f
        cv.drawText("$n", x, y + rad * .4f, t)
    }
    override fun onDraw(cv: Canvas) {
        grid?.let { b ->
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = Color.YELLOW
            val cw = (b[2] - b[0]) / 8; val ch = (b[3] - b[1]) / 8
            for (i in 0..8) {
                cv.drawLine(b[0] + i * cw, b[1], b[0] + i * cw, b[3], p)
                cv.drawLine(b[0], b[1] + i * ch, b[2], b[1] + i * ch, p)
            }
        }
        for (s in steps) {
            for (r in s.cells) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 14f; p.color = s.col
                cv.drawRect(r.left + 9, r.top + 9, r.right - 9, r.bottom - 9, p)
                p.strokeWidth = 3f; p.color = Color.WHITE
                cv.drawRect(r.left + 2, r.top + 2, r.right - 2, r.bottom - 2, p)
            }
            val c0 = s.cells[0]
            badge(cv, c0.left + c0.width() * .2f, c0.top + c0.height() * .2f, s.n, s.col, c0.width() * .17f)
            badge(cv, s.tray.x, s.tray.y, s.n, s.col, 40f)
        }
    }
}

class Cal(c: Context, val done: (Cal, FloatArray) -> Unit) : View(c) {
    private val pt = ArrayList<Float>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.YELLOW; textSize = 44f; textAlign = Paint.Align.CENTER; strokeWidth = 4f }
    init { setBackgroundColor(0x66000000) }
    private fun box() = floatArrayOf(minOf(pt[0], pt[2]), minOf(pt[1], pt[3]), maxOf(pt[0], pt[2]), maxOf(pt[1], pt[3]))
    override fun onDraw(cv: Canvas) {
        val msg = when (pt.size) {
            0 -> "Toca la esquina superior izquierda del tablero"
            2 -> "Toca la esquina inferior derecha del tablero"
            else -> "¿Las líneas amarillas coinciden con el tablero?"
        }
        cv.drawText(msg, width / 2f, height / 6f, p)
        for (i in 0 until pt.size step 2) cv.drawCircle(pt[i], pt[i + 1], 14f, p)
        if (pt.size == 4) {
            val b = box(); val cw = (b[2] - b[0]) / 8; val ch = (b[3] - b[1]) / 8
            for (i in 0..8) {
                cv.drawLine(b[0] + i * cw, b[1], b[0] + i * cw, b[3], p)
                cv.drawLine(b[0], b[1] + i * ch, b[2], b[1] + i * ch, p)
            }
            cv.drawText("REPETIR", width * .25f, height * .93f, p)
            cv.drawText("SÍ, GUARDAR", width * .75f, height * .93f, p)
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN) return true
        if (pt.size == 4) {
            if (e.rawY > height * .85f) { if (e.rawX < width / 2f) pt.clear() else done(this, box()) }
        } else { pt.add(e.rawX); pt.add(e.rawY) }
        invalidate(); return true
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var reader: ImageReader
    private lateinit var proj: MediaProjection
    private lateinit var marks: Marks
    private lateinit var status: TextView
    private lateinit var body: LinearLayout
    private lateinit var btnAuto: TextView
    private lateinit var btnShow: TextView
    @Volatile private var latest: Image? = null
    @Volatile private var stamp = 0L
    private val vs = ArrayList<View>()
    private var W = 0; private var H = 0
    private var beat: View? = null
    private var beatOn = false
    private val h = Handler(Looper.getMainLooper())

    private var geo: FloatArray? = null
    private var live = true
    private var marksOn = true
    private var force = false
    private var busy = false
    private var calibrating = false
    private var lastStamp = 0L
    private var pendSig: String? = null
    private var solvedSig: String? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun lp(touch: Boolean, full: Boolean): WindowManager.LayoutParams {
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or (if (touch) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        val s = if (full) -1 else -2
        return WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT).apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("g", "Guía", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "g").setContentTitle("Guía de Block Blast activa").setSmallIcon(android.R.drawable.ic_menu_view).build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        if (i == null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(dm); W = dm.widthPixels; H = dm.heightPixels
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!)
        proj.registerCallback(object : MediaProjection.Callback() {}, h)
        reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener({ r ->
            val im = r.acquireLatestImage()
            if (im != null) { latest?.close(); latest = im; stamp = SystemClock.uptimeMillis() }
        }, h)
        proj.createVirtualDisplay("g", W, H, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null)
        marks = Marks(this); wm.addView(marks, lp(false, true)); vs.add(marks)
        buildPanel((W * .4f).toInt())
        val pr = getSharedPreferences("g", 0)
        val saved = pr.getString("b", null)
        if (saved != null && pr.getString("wh", "") == "${W}x${H}") geo = saved.split(",").map { it.toFloat() }.toFloatArray()
        setStatus(if (geo != null) "Calibrado · listo" else "Abre el juego y toca Calibrar")
        h.postDelayed(tick, 500)
        return START_NOT_STICKY
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun cleanup() {
        h.removeCallbacksAndMessages(null)
        stopBeat()
        for (v in vs) try { wm.removeView(v) } catch (e: Exception) {}
        vs.clear()
        try { latest?.close() } catch (e: Exception) {}
        latest = null
        try { proj.stop() } catch (e: Exception) {}
    }

    private fun quit() {
        live = false
        cleanup()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    // ---------- menú flotante ----------
    private fun mkBtn(label: String, color: Int, fn: () -> Unit): TextView = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setPadding(10, 22, 10, 22)
        background = GradientDrawable().apply { setColor(color); cornerRadius = 24f }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(5, 5, 5, 5) }
        setOnClickListener { fn() }
    }
    private fun row(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; for (x in v) addView(x) }

    private fun buildPanel(pw: Int) {
        val hdr = TextView(this).apply {
            text = "Block Blast Guía  ▾"; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setPadding(8, 8, 8, 14)
        }
        status = TextView(this).apply { text = "…"; setTextColor(0xFFB8C4FF.toInt()); textSize = 13f; setPadding(8, 0, 8, 10) }
        val bCal = mkBtn("Calibrar", 0xFF2F6BFF.toInt()) { calibrate() }
        val bMark = mkBtn("Marcar", 0xFF1FAA6B.toInt()) { forceNow() }
        btnAuto = mkBtn("Auto: SÍ", 0xFF7B4DFF.toInt()) { toggleLive() }
        btnShow = mkBtn("Marcas: SÍ", 0xFFE08A00.toInt()) { toggleMarks() }
        val bExit = mkBtn("Cerrar", 0xFFD64545.toInt()) { quit() }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status); addView(row(bCal, bMark)); addView(row(btnAuto, btnShow)); addView(row(bExit))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            background = GradientDrawable().apply { setColor(0xEE141A33.toInt()); cornerRadius = 36f }
            addView(hdr); addView(body)
        }
        val lpp = lp(true, false).apply { gravity = Gravity.TOP or Gravity.START; x = W - pw - 16; y = 30; width = pw }
        // arrastra con el título; un toque corto pliega o despliega el menú
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        hdr.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lpp.x; oy = lpp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - sx) > 12 || Math.abs(e.rawY - sy) > 12) moved = true
                    if (moved) { lpp.x = ox + (e.rawX - sx).toInt(); lpp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(root, lpp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    val open = body.visibility != View.VISIBLE
                    body.visibility = if (open) View.VISIBLE else View.GONE
                    hdr.text = if (open) "Block Blast Guía  ▾" else "Block Blast Guía  ▸"
                }
            }
            true
        }
        wm.addView(root, lpp); vs.add(root)
    }

    private fun setStatus(t: String) { h.post { status.text = t } }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun toggleLive() {
        live = !live
        btnAuto.text = if (live) "Auto: SÍ" else "Auto: NO"
        (btnAuto.background as GradientDrawable).setColor(if (live) 0xFF7B4DFF.toInt() else 0xFF555B73.toInt())
        if (live) forceNow()
    }

    private fun toggleMarks() {
        marksOn = !marksOn
        marks.visibility = if (marksOn) View.VISIBLE else View.GONE
        btnShow.text = if (marksOn) "Marcas: SÍ" else "Marcas: NO"
        (btnShow.background as GradientDrawable).setColor(if (marksOn) 0xFFE08A00.toInt() else 0xFF555B73.toInt())
    }

    private fun forceNow() {
        if (geo == null) { toast("Primero toca Calibrar"); return }
        force = true; solvedSig = null; pendSig = null; lastStamp = 0L
        setStatus("Analizando…")
    }

    // ---------- captura ----------
    // Un puntito casi invisible que parpadea: obliga a Android a mandar fotogramas nuevos (solo al calibrar).
    private fun startBeat() {
        if (beat != null) return
        val v = View(this); beat = v
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        wm.addView(v, WindowManager.LayoutParams(2, 2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })
        val r = object : Runnable {
            override fun run() {
                if (beat == null) return
                v.setBackgroundColor(if (beatOn) 0x03000000 else 0x01000000); beatOn = !beatOn
                h.postDelayed(this, 40)
            }
        }
        h.post(r)
    }
    private fun stopBeat() { beat?.let { try { wm.removeView(it) } catch (e: Exception) {} }; beat = null }

    private fun toBitmap(im: Image): Bitmap {
        val pl = im.planes[0]
        val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, H, Bitmap.Config.ARGB_8888)
        pl.buffer.rewind(); full.copyPixelsFromBuffer(pl.buffer)
        return Bitmap.createBitmap(full, 0, 0, W, H)
    }

    private fun waitFrame(min: Long, k: Int, cb: (Bitmap) -> Unit) {
        val im = latest
        if (stamp > min && im != null) { cb(toBitmap(im)); return }
        if (k >= 70) { stopBeat(); calibrating = false; setStatus("No pude leer la pantalla"); toast("No pude leer la pantalla, intenta de nuevo"); return }
        h.postDelayed({ waitFrame(min, k + 1, cb) }, 50)
    }

    // ---------- calibración ----------
    private fun saveGeo(g: FloatArray) {
        geo = g
        getSharedPreferences("g", 0).edit().putString("b", g.joinToString(",")).putString("wh", "${W}x${H}").apply()
        solvedSig = null; pendSig = null; lastStamp = 0L
    }

    private fun calibrate() {
        if (calibrating) return
        calibrating = true
        setStatus("Calibrando…"); toast("Calibrando…")
        marks.steps = listOf(); marks.grid = null; marks.invalidate()
        startBeat()
        waitFrame(SystemClock.uptimeMillis() + 300, 0) { bm ->
            Thread {
                val g = Autocal.find(bm)
                h.post {
                    stopBeat(); calibrating = false
                    if (g != null) {
                        saveGeo(g)
                        marks.grid = g; marks.invalidate()
                        setStatus("✔ Calibrado · listo"); toast("✔ Calibrado")
                        h.postDelayed({ marks.grid = null; marks.invalidate() }, 2500)
                    } else {
                        setStatus("No encontré el tablero")
                        toast("No encontré el tablero. Abre el juego con el tablero a la vista, o toca las 2 esquinas.")
                        manualCal()
                    }
                }
            }.start()
        }
    }

    private fun manualCal() {
        val v = Cal(this) { c, g ->
            saveGeo(g)
            h.post { wm.removeView(c); setStatus("✔ Calibrado · listo"); toast("✔ Calibrado") }
        }
        wm.addView(v, lp(true, true))
    }

    // ---------- modo en vivo ----------
    private val tick = object : Runnable {
        override fun run() { try { step() } catch (e: Exception) {}; h.postDelayed(this, 350) }
    }

    private fun step() {
        val g = geo ?: return
        if ((!live && !force) || busy || calibrating) return
        val im = latest ?: return
        if (stamp == lastStamp && pendSig == null && solvedSig != null) return   // nada nuevo
        lastStamp = stamp
        busy = true
        val bm = toBitmap(im)
        Thread {
            var rd: Reading? = null
            try { rd = Vision.read(bm, g) } catch (e: Exception) {}
            h.post { onRead(rd, g) }
        }.start()
    }

    private fun onRead(rd: Reading?, g: FloatArray) {
        if (rd == null) { busy = false; return }
        if (rd.sig == solvedSig) { pendSig = null; busy = false; return }
        if (rd.sig != pendSig) {
            // algo cambió: se quitan las marcas viejas y se espera a que la pantalla se calme
            pendSig = rd.sig
            if (marks.steps.isNotEmpty()) { marks.steps = listOf(); marks.invalidate() }
            setStatus("Leyendo…")
            busy = false; return
        }
        setStatus("Calculando…")
        Thread {
            val steps = try { plan(rd, g) } catch (e: Exception) { listOf<Step>() }
            h.post {
                marks.steps = steps; marks.invalidate()
                solvedSig = rd.sig; pendSig = null; force = false; busy = false
                setStatus(if (steps.isNotEmpty()) "Jugada lista · sigue el orden 1, 2, 3" else if (rd.pieces.isEmpty()) "Esperando piezas…" else "No hay jugada posible")
            }
        }.start()
    }

    private fun bright(c: Int): Int {
        val hsv = FloatArray(3); Color.colorToHSV(c, hsv)
        hsv[1] = maxOf(hsv[1], .7f); hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    private fun plan(rd: Reading, g: FloatArray): List<Step> {
        val act = rd.pieces.filter { Vision.shape(it.g) != null }
        if (act.isEmpty()) return listOf()
        val mv = Solver.solve(rd.board, act.map { Solver.prep(Vision.shape(it.g)!!) })
        val cw = (g[2] - g[0]) / 8; val ch = (g[3] - g[1]) / 8
        return mv.mapIndexed { n, m ->
            val p = act[m[0]]
            val cells = Vision.shape(p.g)!!.map { (dr, dc) ->
                RectF(g[0] + (m[2] + dc) * cw, g[1] + (m[1] + dr) * ch, g[0] + (m[2] + dc + 1) * cw, g[1] + (m[1] + dr + 1) * ch)
            }
            Step(cells, p.box, n + 1, bright(p.color), PointF(p.box.centerX(), g[3] + 4.35f * ch))
        }
    }
}
