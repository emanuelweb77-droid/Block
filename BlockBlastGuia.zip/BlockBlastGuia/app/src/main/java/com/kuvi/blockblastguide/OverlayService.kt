package com.kuvi.blockblastguide

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.*

class Step(val cells: List<RectF>, val box: RectF, val n: Int, val col: Int)

class Marks(c: Context) : View(c) {
    var steps = listOf<Step>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = 48f; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK }
    private fun badge(cv: Canvas, x: Float, y: Float, n: Int, col: Int) {
        p.style = Paint.Style.FILL; p.color = col; cv.drawCircle(x, y, 36f, p); cv.drawText("$n", x, y + 16f, t)
    }
    override fun onDraw(cv: Canvas) {
        for (s in steps) {
            p.style = Paint.Style.FILL; p.color = s.col; p.alpha = 150
            for (r in s.cells) cv.drawRect(r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = s.col
            for (r in s.cells) cv.drawRect(r, p)
            cv.drawRect(s.box, p)
            badge(cv, s.cells[0].centerX(), s.cells[0].centerY(), s.n, s.col)
            badge(cv, s.box.left, s.box.top, s.n, s.col)
        }
    }
}

class Cal(c: Context, val done: (Cal, FloatArray) -> Unit) : View(c) {
    private val pt = ArrayList<Float>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.YELLOW; textSize = 44f; textAlign = Paint.Align.CENTER }
    init { setBackgroundColor(0x66000000) }
    override fun onDraw(cv: Canvas) {
        cv.drawText(if (pt.isEmpty()) "Toca la esquina superior izquierda del tablero" else "Toca la esquina inferior derecha del tablero", width / 2f, height / 6f, p)
        for (i in 0 until pt.size step 2) cv.drawCircle(pt[i], pt[i + 1], 14f, p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) {
            pt.add(e.rawX); pt.add(e.rawY); invalidate()
            if (pt.size == 4) done(this, floatArrayOf(minOf(pt[0], pt[2]), minOf(pt[1], pt[3]), maxOf(pt[0], pt[2]), maxOf(pt[1], pt[3])))
        }
        return true
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var reader: ImageReader
    private lateinit var proj: MediaProjection
    private lateinit var marks: Marks
    private val vs = ArrayList<View>()
    private var W = 0; private var H = 0
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    private fun lp(touch: Boolean, full: Boolean): WindowManager.LayoutParams {
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or (if (touch) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        val s = if (full) -1 else -2
        return WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT).apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("g", "Guía", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "g").setContentTitle("Guía de Block Blast activa").setSmallIcon(android.R.drawable.ic_menu_view).build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        if (i == null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(dm); W = dm.widthPixels; H = dm.heightPixels
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!)
        proj.registerCallback(object : MediaProjection.Callback() {}, h)
        reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2)
        proj.createVirtualDisplay("g", W, H, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null)
        marks = Marks(this); wm.addView(marks, lp(false, true)); vs.add(marks)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            for ((t, fn) in listOf<Pair<String, () -> Unit>>("Calibrar" to { calibrate() }, "Jugada" to { play() }, "Salir" to { stopSelf() }))
                addView(Button(context).apply { text = t; setOnClickListener { fn() } })
        }
        wm.addView(panel, lp(true, false).apply { gravity = Gravity.TOP or Gravity.END; y = 150 }); vs.add(panel)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        for (v in vs) try { wm.removeView(v) } catch (e: Exception) {}
        try { proj.stop() } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun calibrate() {
        val v = Cal(this) { c, g ->
            getSharedPreferences("g", 0).edit().putString("b", g.joinToString(",")).apply()
            h.post { wm.removeView(c) }
        }
        wm.addView(v, lp(true, true))
    }

    private fun play() {
        val s = getSharedPreferences("g", 0).getString("b", null)
        if (s == null) { Toast.makeText(this, "Primero toca Calibrar", Toast.LENGTH_LONG).show(); return }
        val g = s.split(",").map { it.toFloat() }.toFloatArray()
        marks.visibility = View.GONE
        fun grab(k: Int) {
            val im = reader.acquireLatestImage()
            if (im == null) {
                if (k < 12) h.postDelayed({ grab(k + 1) }, 70)
                else { marks.visibility = View.VISIBLE; Toast.makeText(this, "No pude leer la pantalla, intenta de nuevo", Toast.LENGTH_LONG).show() }
                return
            }
            val pl = im.planes[0]
            val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, H, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(pl.buffer); im.close()
            val bm = Bitmap.createBitmap(full, 0, 0, W, H)
            Thread {
                val st = think(bm, g)
                h.post {
                    marks.steps = st; marks.visibility = View.VISIBLE; marks.invalidate()
                    if (st.isEmpty()) Toast.makeText(this, "No encontré jugada. Prueba Calibrar otra vez.", Toast.LENGTH_LONG).show()
                }
            }.start()
        }
        h.postDelayed({ grab(0) }, 300)
    }

    private fun think(bm: Bitmap, g: FloatArray): List<Step> {
        val act = Vision.pieces(bm, g).filter { Vision.shape(it.g) != null }
        if (act.isEmpty()) return listOf()
        val mv = Solver.solve(Vision.board(bm, g), act.map { Solver.prep(Vision.shape(it.g)!!) })
        val cw = (g[2] - g[0]) / 8; val ch = (g[3] - g[1]) / 8
        return mv.mapIndexed { n, m ->
            val p = act[m[0]]
            val cells = Vision.shape(p.g)!!.map { (dr, dc) ->
                RectF(g[0] + (m[2] + dc) * cw, g[1] + (m[1] + dr) * ch, g[0] + (m[2] + dc + 1) * cw, g[1] + (m[1] + dr + 1) * ch)
            }
            Step(cells, p.box, n + 1, COLS[n])
        }
    }
}
