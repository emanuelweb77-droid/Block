package com.kuvi.blockblastguide

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.*

class Step(val cells: List<RectF>, val box: RectF, val n: Int, val col: Int)
class Plan(val steps: List<Step>, val sig: String)

class Marks(c: Context) : View(c) {
    var steps = listOf<Step>()
    var grid: FloatArray? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = 48f; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK }
    private fun badge(cv: Canvas, x: Float, y: Float, n: Int, col: Int) {
        p.style = Paint.Style.FILL; p.color = col; p.alpha = 255; cv.drawCircle(x, y, 36f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.color = Color.WHITE; cv.drawCircle(x, y, 36f, p)
        cv.drawText("$n", x, y + 16f, t)
    }
    override fun onDraw(cv: Canvas) {
        grid?.let { b ->
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = Color.YELLOW; p.alpha = 255
            val cw = (b[2] - b[0]) / 8; val ch = (b[3] - b[1]) / 8
            for (i in 0..8) {
                cv.drawLine(b[0] + i * cw, b[1], b[0] + i * cw, b[3], p)
                cv.drawLine(b[0], b[1] + i * ch, b[2], b[1] + i * ch, p)
            }
        }
        for (s in steps) {
            val dark = Color.rgb((Color.red(s.col) * .7f).toInt(), (Color.green(s.col) * .7f).toInt(), (Color.blue(s.col) * .7f).toInt())
            p.style = Paint.Style.FILL; p.color = s.col; p.alpha = 170
            for (r in s.cells) cv.drawRect(r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 7f; p.color = dark
            for (r in s.cells) cv.drawRect(r, p)
            cv.drawRect(s.box, p)
            badge(cv, s.cells[0].centerX(), s.cells[0].centerY(), s.n, s.col)
            badge(cv, s.box.left, s.box.top, s.n, s.col)
        }
    }
}

class Cal(c: Context, val done: (Cal, FloatArray) -> Unit) : View(c) {
    private val pt = ArrayList<Float>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.YELLOW; textSize = 44f; textAlign = Paint.Align.CENTER; strokeWidth = 4f }
    init { setBackgroundColor(0x66000000) }
    private fun box() = floatArrayOf(minOf(pt[0], pt[2]), minOf(pt[1], pt[3]), maxOf(pt[0], pt[2]), maxOf(pt[1], pt[3]))
    override fun onDraw(cv: Canvas) {
        val msg = when (pt.size) {
            0 -> "Toca la esquina superior izquierda del tablero"
            2 -> "Toca la esquina inferior derecha del tablero"
            else -> "¿Las líneas amarillas coinciden con el tablero?"
        }
        cv.drawText(msg, width / 2f, height / 6f, p)
        for (i in 0 until pt.size step 2) cv.drawCircle(pt[i], pt[i + 1], 14f, p)
        if (pt.size == 4) {
            val b = box(); val cw = (b[2] - b[0]) / 8; val ch = (b[3] - b[1]) / 8
            for (i in 0..8) {
                cv.drawLine(b[0] + i * cw, b[1], b[0] + i * cw, b[3], p)
                cv.drawLine(b[0], b[1] + i * ch, b[2], b[1] + i * ch, p)
            }
            cv.drawText("REPETIR", width * .25f, height * .93f, p)
            cv.drawText("SÍ, GUARDAR", width * .75f, height * .93f, p)
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN) return true
        if (pt.size == 4) {
            if (e.rawY > height * .85f) { if (e.rawX < width / 2f) pt.clear() else done(this, box()) }
        } else { pt.add(e.rawX); pt.add(e.rawY) }
        invalidate(); return true
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var reader: ImageReader
    private lateinit var proj: MediaProjection
    private lateinit var marks: Marks
    @Volatile private var latest: Image? = null
    @Volatile private var stamp = 0L
    private val vs = ArrayList<View>()
    private var W = 0; private var H = 0
    private var shown = true
    private var beat: View? = null
    private var beatOn = false
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    private fun lp(touch: Boolean, full: Boolean): WindowManager.LayoutParams {
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or (if (touch) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        val s = if (full) -1 else -2
        return WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT).apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("g", "Guía", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "g").setContentTitle("Guía de Block Blast activa").setSmallIcon(android.R.drawable.ic_menu_view).build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        if (i == null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(dm); W = dm.widthPixels; H = dm.heightPixels
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!)
        proj.registerCallback(object : MediaProjection.Callback() {}, h)
        reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener({ r ->
            val im = r.acquireLatestImage()
            if (im != null) { latest?.close(); latest = im; stamp = SystemClock.uptimeMillis() }
        }, h)
        proj.createVirtualDisplay("g", W, H, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null)
        marks = Marks(this); wm.addView(marks, lp(false, true)); vs.add(marks)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            for ((t, fn) in listOf<Pair<String, () -> Unit>>("Calibrar" to { calibrate() }, "Jugada" to { play() }, "Salir" to { stopSelf() }))
                addView(Button(context).apply { text = t; setOnClickListener { fn() } })
        }
        wm.addView(panel, lp(true, false).apply { gravity = Gravity.TOP or Gravity.END; y = 150 }); vs.add(panel)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopBeat()
        for (v in vs) try { wm.removeView(v) } catch (e: Exception) {}
        try { latest?.close() } catch (e: Exception) {}
        try { proj.stop() } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun hideMarks() { if (shown) { try { wm.removeView(marks) } catch (e: Exception) {}; shown = false } }
    private fun showMarks() { if (!shown) { try { wm.addView(marks, lp(false, true)) } catch (e: Exception) {}; shown = true } }

    // Un puntito casi invisible que parpadea: obliga a Android a mandar fotogramas nuevos.
    private fun startBeat() {
        if (beat != null) return
        val v = View(this); beat = v
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        wm.addView(v, WindowManager.LayoutParams(2, 2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })
        val r = object : Runnable {
            override fun run() {
                if (beat == null) return
                v.setBackgroundColor(if (beatOn) 0x03000000 else 0x01000000); beatOn = !beatOn
                h.postDelayed(this, 40)
            }
        }
        h.post(r)
    }
    private fun stopBeat() { beat?.let { try { wm.removeView(it) } catch (e: Exception) {} }; beat = null }

    private fun toBitmap(im: Image): Bitmap {
        val pl = im.planes[0]
        val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, H, Bitmap.Config.ARGB_8888)
        pl.buffer.rewind(); full.copyPixelsFromBuffer(pl.buffer)
        return Bitmap.createBitmap(full, 0, 0, W, H)
    }

    // Si la captura todavía trae nuestras marcas (aro blanco de los números), no sirve.
    private fun polluted(bm: Bitmap, st: List<Step>): Boolean {
        for (s in st) for (pt in listOf(Pair(s.cells[0].centerX(), s.cells[0].centerY()), Pair(s.box.left, s.box.top))) {
            val x = (pt.first + 36).toInt(); val y = pt.second.toInt()
            if (x in 0 until bm.width && y in 0 until bm.height) {
                val c = bm.getPixel(x, y)
                if (Color.red(c) >= 248 && Color.green(c) >= 248 && Color.blue(c) >= 248) return true
            }
        }
        return false
    }

    // Espera un fotograma posterior a "min" y limpio de marcas.
    private fun waitFrame(min: Long, prev: List<Step>, k: Int, cb: (Bitmap) -> Unit) {
        val im = latest
        if (stamp > min && im != null) {
            val bm = toBitmap(im)
            if (!polluted(bm, prev) || k >= 40) { cb(bm); return }
        }
        if (k >= 70) { stopBeat(); showMarks(); toast("No pude leer la pantalla, intenta de nuevo"); return }
        h.postDelayed({ waitFrame(min, prev, k + 1, cb) }, 50)
    }

    private fun calibrate() {
        val prev = marks.steps
        toast("Calibrando…")
        marks.grid = null
        hideMarks(); startBeat()
        waitFrame(SystemClock.uptimeMillis() + 300, prev, 0) { bm ->
            Thread {
                val g = Autocal.find(bm)
                h.post {
                    stopBeat()
                    if (g != null) {
                        getSharedPreferences("g", 0).edit().putString("b", g.joinToString(",")).apply()
                        marks.steps = listOf(); marks.grid = g; showMarks(); marks.invalidate()
                        toast("✔ Calibrado. Ya puedes tocar Jugada")
                        h.postDelayed({ marks.grid = null; marks.invalidate() }, 2500)
                    } else {
                        showMarks()
                        toast("No encontré el tablero. Abre el juego con el tablero a la vista, o toca las 2 esquinas")
                        manualCal()
                    }
                }
            }.start()
        }
    }

    private fun manualCal() {
        val v = Cal(this) { c, g ->
            getSharedPreferences("g", 0).edit().putString("b", g.joinToString(",")).apply()
            h.post { wm.removeView(c); toast("✔ Calibrado") }
        }
        wm.addView(v, lp(true, true))
    }

    private fun play() {
        val s = getSharedPreferences("g", 0).getString("b", null)
        if (s == null) { calibrate(); return }
        val g = s.split(",").map { it.toFloat() }.toFloatArray()
        val prev = marks.steps
        marks.grid = null
        hideMarks(); startBeat()
        // Se analiza varias veces hasta que dos lecturas seguidas coinciden (así no se lee en medio de una animación).
        fun attempt(n: Int, last: String?) {
            waitFrame(SystemClock.uptimeMillis() + (if (n == 0) 300 else 250), prev, 0) { bm ->
                Thread {
                    val r = think(bm, g)
                    h.post {
                        if (r.sig == last || n >= 5) {
                            stopBeat(); marks.steps = r.steps; showMarks()
                            if (r.steps.isEmpty()) toast("No veo piezas o no hay jugada. Si el tablero cambió de lugar, toca Calibrar")
                            marks.invalidate()
                        } else {
                            attempt(n + 1, r.sig)
                        }
                    }
                }.start()
            }
        }
        attempt(0, null)
    }

    private fun think(bm: Bitmap, g: FloatArray): Plan {
        val board = Vision.board(bm, g)
        val all = Vision.pieces(bm, g)
        val sig = board.joinToString(",") + "|" + all.joinToString(";") { p -> Vision.shape(p.g)?.joinToString("") { "${it.first}${it.second}" } ?: "-" }
        val act = all.filter { Vision.shape(it.g) != null }
        if (act.isEmpty()) return Plan(listOf(), sig)
        val mv = Solver.solve(board, act.map { Solver.prep(Vision.shape(it.g)!!) })
        val cw = (g[2] - g[0]) / 8; val ch = (g[3] - g[1]) / 8
        val steps = mv.mapIndexed { n, m ->
            val p = act[m[0]]
            val cells = Vision.shape(p.g)!!.map { (dr, dc) ->
                RectF(g[0] + (m[2] + dc) * cw, g[1] + (m[1] + dr) * ch, g[0] + (m[2] + dc + 1) * cw, g[1] + (m[1] + dr + 1) * ch)
            }
            Step(cells, p.box, n + 1, p.color)
        }
        return Plan(steps, sig)
    }
}
