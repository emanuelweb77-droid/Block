package com.kuvi.blockblastguide

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.*

class Step(val cells: List<RectF>, val box: RectF, val n: Int, val col: Int, val tray: PointF)

// Las marcas se dibujan lejos del centro de las casillas y fuera de la zona donde se leen las piezas,
// así nunca ensucian la lectura de la pantalla.
class Marks(c: Context) : View(c) {
    var steps = listOf<Step>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK }
    private fun badge(cv: Canvas, x: Float, y: Float, n: Int, col: Int, rad: Float) {
        p.style = Paint.Style.FILL; p.color = col; cv.drawCircle(x, y, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = rad * .18f; p.color = Color.WHITE; cv.drawCircle(x, y, rad, p)
        t.textSize = rad * 1.15f
        cv.drawText("$n", x, y + rad * .4f, t)
    }
    override fun onDraw(cv: Canvas) {
        for (s in steps) {
            for (r in s.cells) {
                p.style = Paint.Style.STROKE; p.strokeWidth = r.width() * .045f; p.color = s.col
                cv.drawRect(r.left + r.width()*.065f, r.top + r.height()*.065f, r.right - r.width()*.065f, r.bottom - r.height()*.065f, p)
                p.strokeWidth = 3f; p.color = Color.WHITE
                cv.drawRect(r.left + 2, r.top + 2, r.right - 2, r.bottom - 2, p)
            }
            badge(cv, s.tray.x, s.tray.y, s.n, s.col, 16f)

        }
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var reader: ImageReader
    private lateinit var proj: MediaProjection
    private lateinit var marks: Marks
    private lateinit var status: TextView
    private lateinit var body: LinearLayout
    private lateinit var btnAuto: TextView
    private lateinit var bCal: TextView
    private lateinit var progress: ProgressBar
    private lateinit var panel: LinearLayout
    private var reference: Int? = null
    private var generation = 0
    private var destroyed = false
    private var display: android.hardware.display.VirtualDisplay? = null
    private val gate = StableGate()
    private var badSince = 0L
    private var calCount = 0
    private var calCandidate: FloatArray? = null
    private var calRef: Int? = null
    private var calStart = 0L
    private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()
    @Volatile private var latest: Image? = null
    @Volatile private var stamp = 0L
    private val vs = ArrayList<View>()
    private var W = 0; private var H = 0
    private var beat: View? = null
    private var beatOn = false
    private val h = Handler(Looper.getMainLooper())

    private var geo: FloatArray? = null
    private var live = false
    private var busy = false
    private var calibrating = false
    private var lastStamp = 0L
    private var solvedSig: String? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun lp(touch: Boolean, full: Boolean): WindowManager.LayoutParams {
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or (if (touch) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        val s = if (full) -1 else -2
        return WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT).apply {
            if (!touch) alpha = .75f
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (::proj.isInitialized) return START_NOT_STICKY
        if (i == null || !i.hasExtra("data")) { stopSelf(); return START_NOT_STICKY }
        val stop = PendingIntent.getService(this, 9, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("g", "Guía", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "g").setContentTitle("Guía de Block Blast activa").setSmallIcon(android.R.drawable.ic_menu_view).addAction(Notification.Action.Builder(null, "Detener", stop).build()).build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(dm); W = dm.widthPixels; H = dm.heightPixels
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!)
        proj.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener({ r ->
            val im = r.acquireLatestImage()
            if (im != null) { latest?.close(); latest = im; stamp = SystemClock.uptimeMillis() }
        }, h)
        display = proj.createVirtualDisplay("g", W, H, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null)
        marks = Marks(this); wm.addView(marks, lp(false, true)); vs.add(marks)
        buildPanel((W * .4f).toInt())
        setStatus("Abre el juego y usa Auto calibrar")
        startBeat()
        h.postDelayed(tick, 500)
        return START_NOT_STICKY
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun cleanup() {
        destroyed = true; generation++; worker.shutdownNow()
        h.removeCallbacksAndMessages(null)
        stopBeat()
        for (v in vs) try { wm.removeView(v) } catch (e: Exception) {}
        vs.clear()
        try { latest?.close() } catch (e: Exception) {}
        latest = null
        try { reader.setOnImageAvailableListener(null, null); display?.release(); reader.close() } catch (e: Exception) {}
        try { proj.stop() } catch (e: Exception) {}
    }

    // ---------- menú flotante ----------
    private fun mkBtn(label: String, color: Int, fn: () -> Unit): TextView = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setPadding(10, 22, 10, 22)
        background = GradientDrawable().apply { setColor(color); cornerRadius = 24f }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(5, 5, 5, 5) }
        setOnClickListener { fn() }
    }
    private fun row(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; for (x in v) addView(x) }

    private fun buildPanel(pw: Int) {
        val hdr = TextView(this).apply {
            text = "Block Blast Guía  ▾"; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setPadding(8, 8, 8, 14)
        }
        status = TextView(this).apply { text = "…"; setTextColor(0xFFB8C4FF.toInt()); textSize = 12f; minLines = 2; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(8, 0, 8, 10) }
        bCal = mkBtn("Auto calibrar", 0xFF2F6BFF.toInt()) { calibrate() }
        btnAuto = mkBtn("Auto marcar", 0xFF1FAA6B.toInt()) { toggleLive() }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(bCal)); addView(row(btnAuto)); addView(status); addView(progress)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            background = GradientDrawable().apply { setColor(0xEE141A33.toInt()); cornerRadius = 36f }
            addView(hdr); addView(body)
        }
        val lpp = lp(true, false).apply { gravity = Gravity.TOP or Gravity.START; x = W - pw - 16; y = 30; width = pw }
        // arrastra con el título; un toque corto pliega o despliega el menú
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        hdr.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lpp.x; oy = lpp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - sx) > 12 || Math.abs(e.rawY - sy) > 12) moved = true
                    if (moved) { lpp.x = (ox + (e.rawX - sx).toInt()).coerceIn(0, (W-root.width).coerceAtLeast(0)); lpp.y = (oy + (e.rawY - sy).toInt()).coerceIn(0, (H-root.height).coerceAtLeast(0)); wm.updateViewLayout(root, lpp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    val open = body.visibility != View.VISIBLE
                    body.visibility = if (open) View.VISIBLE else View.GONE
                    hdr.text = if (open) "Block Blast Guía  ▾" else "Block Blast Guía  ▸"
                }
            }
            true
        }
        panel = root; wm.addView(root, lpp); vs.add(root)
    }

    private fun setStatus(t: String) { h.post { status.text = t } }

    private fun toggleLive() {
        if (geo == null) { setStatus("Primero usa Auto calibrar"); return }
        if (calibrating) return
        generation++; live = !live; gate.reset(); solvedSig = null
        btnAuto.text = if (live) "Auto marcar · ON" else "Auto marcar"
        progress.visibility = View.GONE
        if (!live) { marks.steps = emptyList(); marks.invalidate() }
        setStatus(if (live) "Marcando…" else "Pausado")
    }

    // ---------- captura ----------
    // Fresh frames without removing the visible recommendation. The pulse is outside the game sampling area.
    private fun startBeat() {
        if (beat != null) return
        val v = View(this); beat = v
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        wm.addView(v, WindowManager.LayoutParams(2, 2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })
        val r = object : Runnable {
            override fun run() {
                if (beat == null) return
                v.setBackgroundColor(if (beatOn) 0x03000000 else 0x01000000); beatOn = !beatOn
                h.postDelayed(this, 120)
            }
        }
        h.post(r)
    }
    private fun stopBeat() { beat?.let { try { wm.removeView(it) } catch (e: Exception) {} }; beat = null }

    private fun toBitmap(im: Image): Bitmap {
        val pl = im.planes[0]
        val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, H, Bitmap.Config.ARGB_8888)
        pl.buffer.rewind(); full.copyPixelsFromBuffer(pl.buffer)
        val result = Bitmap.createBitmap(full, 0, 0, W, H)
        if (result !== full) full.recycle()
        return result
    }

    private fun overlaps(g: FloatArray): Boolean {
        val xy = IntArray(2); panel.getLocationOnScreen(xy)
        return RectF.intersects(RectF(xy[0].toFloat(), xy[1].toFloat(), (xy[0]+panel.width).toFloat(), (xy[1]+panel.height).toFloat()),
            RectF(g[0], g[1], g[2], minOf(H.toFloat(), g[3]+(g[3]-g[1])*.5f)))
    }
    private fun calibrate() {
        if (calibrating) return
        generation++; live = false; calibrating = true; geo = null; reference = null
        btnAuto.text = "Auto marcar"; btnAuto.isEnabled = false; bCal.isEnabled = false
        calCount = 0; calCandidate = null; calRef = null; calStart = SystemClock.uptimeMillis()
        gate.reset(); solvedSig = null; marks.steps = emptyList(); marks.invalidate()
        progress.progress = 0; progress.visibility = View.VISIBLE; setStatus("Calibrando…")
    }
    private fun finishCalibration(message: String) {
        calibrating = false; bCal.isEnabled = true; btnAuto.isEnabled = true
        if (geo == null) progress.visibility = View.GONE
        setStatus(message)
    }
    private fun readCalibration() {
        if (SystemClock.uptimeMillis()-calStart > 20000) {
            generation++; finishCalibration("No pude calibrar. Deja el tablero visible e intenta otra vez."); return
        }
        if (busy || stamp == lastStamp) return
        val im = latest ?: return
        lastStamp = stamp; val bm = toBitmap(im); busy = true; val token = generation
        worker.execute {
            var g: FloatArray? = null; var ref: Int? = null
            try { g = Autocal.find(bm); g?.let { ref = Vision.emptyReference(bm, it) } } catch (e: Exception) {}
            finally { bm.recycle() }
            h.post {
                busy = false
                if (destroyed || token != generation) return@post
                val found = g; val empty = ref
                if (found == null || empty == null || overlaps(found)) {
                    calCount = 0; calCandidate = null; progress.progress = 0
                    setStatus(if (found != null && overlaps(found)) "Calibrando… mueve el menú fuera del tablero" else "Calibrando… deja el tablero quieto y visible")
                } else {
                    val previous = calCandidate
                    if (previous == null || found.indices.any { kotlin.math.abs(found[it]-previous[it]) > 5f } ||
                        calRef?.let { Vision.colorDistance(it, empty) > 20.0 } == true) calCount = 0
                    calCandidate = found; calRef = empty; calCount++; progress.progress = calCount*25
                    setStatus("Calibrando…")
                    if (calCount >= 4) {
                        geo = found; reference = empty; finishCalibration("Calibrado · listo")
                    }
                }
            }
        }
    }

    // ---------- modo en vivo ----------
    private val tick = object : Runnable {
        override fun run() {
            if (destroyed) return
            try { if (calibrating) readCalibration() else step() } catch (e: Exception) { busy = false; setStatus("No pude leer la pantalla. Reintenta la calibración.") }
            h.postDelayed(this, 120)
        }
    }
    private fun step() {
        val g = geo ?: return
        if (!live || busy || calibrating || stamp == lastStamp) return
        if (overlaps(g)) {
            marks.steps = emptyList(); marks.invalidate(); solvedSig = null; gate.reset()
            setStatus("Mueve el menú fuera del tablero"); return
        }
        val im = latest ?: return
        val ref = reference ?: return
        lastStamp = stamp; busy = true; val bm = toBitmap(im); val token = generation
        worker.execute {
            val rd = try { Vision.read(bm, g, ref) } catch (e: Exception) { null } finally { bm.recycle() }
            h.post {
                busy = false
                if (!destroyed && token == generation && live) onRead(rd, g, token)
            }
        }
    }
    private fun onRead(rd: Reading?, g: FloatArray, token: Int) {
        val now = SystemClock.uptimeMillis()
        if (rd == null) {
            gate.reset()
            if (badSince == 0L) badSince = now
            if (now-badSince > 700) { marks.steps = emptyList(); marks.invalidate(); solvedSig = null; setStatus("Marcando… verificando piezas") }
            return
        }
        badSince = 0
        if (!gate.offer(rd.sig, now)) return
        if (rd.sig == solvedSig) { setStatus("Marcando…"); return }
        marks.steps = emptyList(); marks.invalidate(); setStatus("Marcando…"); busy = true
        worker.execute {
            val steps = try { plan(rd, g) } catch (e: Exception) { emptyList<Step>() }
            h.post {
                if (destroyed || token != generation || !live) { busy = false; return@post }
                // Copy the latest frame on the capture thread; decode it on the worker.
                val fresh = try { latest?.let { toBitmap(it) } } catch (e: Exception) { null }
                val ref = reference
                if (fresh == null || ref == null) { fresh?.recycle(); busy = false; gate.reset(); return@post }
                worker.execute {
                    val same = try { Vision.read(fresh, g, ref).sig == rd.sig }
                        catch (e: Exception) { false } finally { fresh.recycle() }
                    h.post verify@{
                        busy = false
                        if (destroyed || token != generation || !live) return@verify
                        if (!same) { gate.reset(); solvedSig = null; return@verify }
                        marks.steps = steps; marks.invalidate(); solvedSig = rd.sig
                        setStatus(if (steps.isNotEmpty()) "Marcando…" else if (rd.pieces.isEmpty()) "Marcando… esperando piezas" else "Marcando… sin jugada válida")
                    }
                }
            }
        }
    }

    private fun bright(c: Int): Int {
        val hsv = FloatArray(3); Color.colorToHSV(c, hsv)
        hsv[1] = maxOf(hsv[1], .7f); hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    private fun plan(rd: Reading, g: FloatArray): List<Step> {
        val act = rd.pieces.filter { Vision.shape(it.g) != null }
        if (act.isEmpty()) return listOf()
        val mv = Solver.solve(rd.board, act.map { Solver.prep(Vision.shape(it.g)!!) })
        val cw = (g[2] - g[0]) / 8; val ch = (g[3] - g[1]) / 8
        return mv.take(1).mapIndexed { n, m ->
            val p = act[m[0]]
            check(Solver.put(rd.board, Solver.prep(Vision.shape(p.g)!!), m[1], m[2]) != null)
            val cells = Vision.shape(p.g)!!.map { (dr, dc) ->
                RectF(g[0] + (m[2] + dc) * cw, g[1] + (m[1] + dr) * ch, g[0] + (m[2] + dc + 1) * cw, g[1] + (m[1] + dr + 1) * ch)
            }
            Step(cells, p.box, n + 1, bright(p.color), PointF(p.box.centerX(), minOf(H-20f, g[3] + 4.35f * ch)))
        }
    }
}
