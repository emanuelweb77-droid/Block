package com.kuvi.blockblastguide

object Solver {
    val PC = IntArray(256) { Integer.bitCount(it) }
    class P(val m: IntArray, val h: Int, val w: Int)

    fun prep(cells: List<Pair<Int, Int>>): P {
        val h = cells.maxOf { it.first } + 1; val w = cells.maxOf { it.second } + 1
        val m = IntArray(h)
        for ((r, c) in cells) m[r] = m[r] or (1 shl c)
        return P(m, h, w)
    }

    fun put(B: IntArray, p: P, r: Int, c: Int): Pair<IntArray, Int>? {
        if(B.size!=8 || B.any { it !in 0..255 } || r<0 || c<0 || r+p.h>8 || c+p.w>8) return null
        val n = B.copyOf()
        for (i in 0 until p.h) { val mk = p.m[i] shl c; if ((n[r + i] and mk) != 0) return null; n[r + i] = n[r + i] or mk }
        var cm = 255
        for (i in 0..7) cm = cm and n[i]
        val fr = BooleanArray(8) { n[it] == 255 }
        var k = 0
        for (i in 0..7) { if (fr[i]) k++; n[i] = if (fr[i]) 0 else (n[i] and cm.inv() and 255) }
        k += PC[cm]
        return Pair(n, k)
    }

    private fun free(B: IntArray, r: Int) = B[r].inv() and 255

    // Valora el tablero final: líneas limpiadas, espacio libre, huecos tapados, orden y "movilidad"
    // (cuántos lugares quedan para piezas grandes como 3x3, 2x2 y barras de 5).
    fun ev(B: IntArray, k: Int, kq: Int): Int {
        var e = 0; var hole = 0; var iso = 0; var tr = 0
        for (r in 0..7) {
            val v = B[r]; val E = v.inv() and 255
            e += 8 - PC[v]
            val up = if (r > 0) B[r - 1] else 255; val dn = if (r < 7) B[r + 1] else 255
            val lf = ((v shl 1) or 1) and 255; val rt = (v shr 1) or 128
            iso += PC[E and lf and rt and up and dn]
            hole += PC[E and ((lf and rt) or (lf and up) or (lf and dn) or (rt and up) or (rt and dn) or (up and dn))]
            tr += PC[(v xor (v shr 1)) and 127]
            if (r < 7) tr += PC[v xor B[r + 1]]
        }
        var n2 = 0; var n3 = 0; var h5 = 0; var v5 = 0
        for (r in 0..7) {
            val f = free(B, r)
            h5 += PC[f and (f shr 1) and (f shr 2) and (f shr 3) and (f shr 4)]
            if (r < 7) { val f2 = f and free(B, r + 1); n2 += PC[f2 and (f2 shr 1)] }
            if (r < 6) { val f3 = f and free(B, r + 1) and free(B, r + 2); n3 += PC[f3 and (f3 shr 1) and (f3 shr 2)] }
            if (r < 4) v5 += PC[f and free(B, r + 1) and free(B, r + 2) and free(B, r + 3) and free(B, r + 4)]
        }
        val mob = minOf(n2, 10) * 2 + minOf(n3, 6) * 4 + minOf(h5, 5) * 2 + minOf(v5, 5) * 2
        return k * 60 + kq * 30 + e * 2 - iso * 30 - hole * 6 - tr * 3 + mob
    }

    // Devuelve pasos [indicePieza, fila, columna, líneasLimpiadas] en el orden a jugar.
    fun solve(B:IntArray,list:List<P>):List<IntArray> {
        require(B.size==8 && B.all { it in 0..255 } && list.size<=3)
        var best=Int.MIN_VALUE; var answer=listOf<IntArray>()
        data class Candidate(val move:IntArray,val board:IntArray,val score:Int)
        fun go(board:IntArray,remaining:List<Int>,moves:List<IntArray>,lines:Int,combo:Int) {
            if(Thread.currentThread().isInterrupted) return
            val score=moves.size*100000+ev(board,lines,combo)
            if(score>best) { best=score; answer=moves }
            for(index in remaining) {
                val piece=list[index]
                if(remaining.size==1) {
                    // Last ply: evaluate directly, without sorting or evaluating each board twice.
                    for(r in 0..8-piece.h) for(c in 0..8-piece.w) {
                        val result=put(board,piece,r,c) ?: continue
                        val finalScore=(moves.size+1)*100000+ev(result.first,lines+result.second,combo+result.second*result.second)
                        if(finalScore>best) {
                            best=finalScore; answer=moves+intArrayOf(index,r,c,result.second)
                        }
                    }
                    continue
                }
                val candidates=ArrayList<Candidate>()
                for(r in 0..8-piece.h) for(c in 0..8-piece.w) {
                    val result=put(board,piece,r,c) ?: continue
                    candidates.add(Candidate(intArrayOf(index,r,c,result.second),result.first,ev(result.first,result.second,result.second*result.second)))
                }
                for(candidate in candidates.sortedByDescending { it.score }.take(20)) {
                    val cleared=candidate.move[3]
                    go(candidate.board,remaining.filter { it!=index },moves+candidate.move,lines+cleared,combo+cleared*cleared)
                }
            }
        }
        go(B,list.indices.toList(),emptyList(),0,0); return answer
    }

}

