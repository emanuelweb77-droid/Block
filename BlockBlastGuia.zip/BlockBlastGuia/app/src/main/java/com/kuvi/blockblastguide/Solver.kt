package com.kuvi.blockblastguide

object Solver {
    val PC = IntArray(256) { Integer.bitCount(it) }
    class P(val m: IntArray, val h: Int, val w: Int)

    fun prep(cells: List<Pair<Int, Int>>): P {
        val h = cells.maxOf { it.first } + 1; val w = cells.maxOf { it.second } + 1
        val m = IntArray(h)
        for ((r, c) in cells) m[r] = m[r] or (1 shl c)
        return P(m, h, w)
    }

    fun put(B: IntArray, p: P, r: Int, c: Int): Pair<IntArray, Int>? {
        if(B.size!=8 || B.any { it !in 0..255 } || r<0 || c<0 || r+p.h>8 || c+p.w>8) return null
        val n = B.copyOf()
        for (i in 0 until p.h) { val mk = p.m[i] shl c; if ((n[r + i] and mk) != 0) return null; n[r + i] = n[r + i] or mk }
        var cm = 255
        for (i in 0..7) cm = cm and n[i]
        val fr = BooleanArray(8) { n[it] == 255 }
        var k = 0
        for (i in 0..7) { if (fr[i]) k++; n[i] = if (fr[i]) 0 else (n[i] and cm.inv() and 255) }
        k += PC[cm]
        return Pair(n, k)
    }

    /** Igual que put, pero sin crear objetos: escribe el resultado en out. Devuelve las líneas limpiadas o -1 si no cabe. */
    internal fun putInto(B: IntArray, p: P, r: Int, c: Int, out: IntArray): Int {
        if (r < 0 || c < 0 || r + p.h > 8 || c + p.w > 8) return -1
        for (i in 0..7) out[i] = B[i]
        for (i in 0 until p.h) {
            val mk = p.m[i] shl c
            if ((out[r + i] and mk) != 0) return -1
            out[r + i] = out[r + i] or mk
        }
        var cm = 255
        for (i in 0..7) cm = cm and out[i]
        var full = 0; var k = 0
        for (i in 0..7) if (out[i] == 255) { full = full or (1 shl i); k++ }
        for (i in 0..7) out[i] = if (((full shr i) and 1) == 1) 0 else (out[i] and cm.inv() and 255)
        return k + PC[cm]
    }

    private fun free(B: IntArray, r: Int) = B[r].inv() and 255

    fun ev(B: IntArray, k: Int, kq: Int): Int = evaluate(B, k, kq, 0)

    /**
     * Valora un tablero: líneas limpiadas (y combos), espacio libre, huecos tapados, orden, "movilidad"
     * (lugares que quedan para piezas grandes) y líneas casi completas, que son las que alimentan los combos.
     * streak = cuántas piezas seguidas de esta jugada limpian línea (mantiene viva la racha).
     */
    internal fun evaluate(B: IntArray, k: Int, kq: Int, streak: Int): Int {
        var e = 0; var hole = 0; var iso = 0; var tr = 0; var near = 0
        for (r in 0..7) {
            val v = B[r]; val E = v.inv() and 255
            e += 8 - PC[v]
            val up = if (r > 0) B[r - 1] else 255; val dn = if (r < 7) B[r + 1] else 255
            val lf = ((v shl 1) or 1) and 255; val rt = (v shr 1) or 128
            iso += PC[E and lf and rt and up and dn]
            hole += PC[E and ((lf and rt) or (lf and up) or (lf and dn) or (rt and up) or (rt and dn) or (up and dn))]
            tr += PC[(v xor (v shr 1)) and 127]
            if (r < 7) tr += PC[v xor B[r + 1]]
            val rowCount = PC[v]
            if (rowCount in 6..7) near += rowCount - 5
        }
        for (c in 0..7) {
            var cnt = 0
            for (r in 0..7) cnt += (B[r] shr c) and 1
            if (cnt in 6..7) near += cnt - 5
        }
        var n2 = 0; var n3 = 0; var h5 = 0; var v5 = 0
        for (r in 0..7) {
            val f = free(B, r)
            h5 += PC[f and (f shr 1) and (f shr 2) and (f shr 3) and (f shr 4)]
            if (r < 7) { val f2 = f and free(B, r + 1); n2 += PC[f2 and (f2 shr 1)] }
            if (r < 6) { val f3 = f and free(B, r + 1) and free(B, r + 2); n3 += PC[f3 and (f3 shr 1) and (f3 shr 2)] }
            if (r < 4) v5 += PC[f and free(B, r + 1) and free(B, r + 2) and free(B, r + 3) and free(B, r + 4)]
        }
        val mob = minOf(n2, 10) * 2 + minOf(n3, 6) * 4 + minOf(h5, 5) * 2 + minOf(v5, 5) * 2
        return k * 60 + kq * 30 + e * 2 - iso * 30 - hole * 6 - tr * 3 + mob + near * 4 + streak * 40
    }

    /** Piezas típicas del juego (incluye las diagonales): sirven para imaginar el próximo turno. */
    private val LIB: List<P> by lazy {
        val raw = listOf(
            intArrayOf(0,0),
            intArrayOf(0,0, 0,1), intArrayOf(0,0, 1,0),
            intArrayOf(0,0, 0,1, 0,2), intArrayOf(0,0, 1,0, 2,0),
            intArrayOf(0,0, 0,1, 1,0), intArrayOf(0,0, 0,1, 1,1), intArrayOf(0,0, 1,0, 1,1), intArrayOf(0,1, 1,0, 1,1),
            intArrayOf(0,0, 0,1, 0,2, 0,3), intArrayOf(0,0, 1,0, 2,0, 3,0),
            intArrayOf(0,0, 0,1, 0,2, 0,3, 0,4), intArrayOf(0,0, 1,0, 2,0, 3,0, 4,0),
            intArrayOf(0,0, 0,1, 1,0, 1,1),
            intArrayOf(0,0, 0,1, 0,2, 1,0, 1,1, 1,2, 2,0, 2,1, 2,2),
            intArrayOf(0,0, 0,1, 0,2, 1,0, 1,1, 1,2), intArrayOf(0,0, 0,1, 1,0, 1,1, 2,0, 2,1),
            intArrayOf(0,0, 1,0, 2,0, 2,1), intArrayOf(0,1, 1,1, 2,1, 2,0), intArrayOf(0,0, 0,1, 1,0, 2,0), intArrayOf(0,0, 0,1, 1,1, 2,1),
            intArrayOf(0,0, 0,1, 0,2, 1,0), intArrayOf(0,0, 0,1, 0,2, 1,2), intArrayOf(0,2, 1,0, 1,1, 1,2), intArrayOf(0,0, 1,0, 1,1, 1,2),
            intArrayOf(0,0, 0,1, 0,2, 1,1), intArrayOf(1,0, 1,1, 1,2, 0,1), intArrayOf(0,0, 1,0, 2,0, 1,1), intArrayOf(0,1, 1,1, 2,1, 1,0),
            intArrayOf(0,1, 0,2, 1,0, 1,1), intArrayOf(0,0, 0,1, 1,1, 1,2), intArrayOf(0,0, 1,0, 1,1, 2,1), intArrayOf(0,1, 1,0, 1,1, 2,0),
            intArrayOf(0,0, 1,0, 2,0, 2,1, 2,2), intArrayOf(0,2, 1,2, 2,2, 2,1, 2,0), intArrayOf(0,0, 0,1, 0,2, 1,0, 2,0), intArrayOf(0,0, 0,1, 0,2, 1,2, 2,2),
            intArrayOf(0,0, 1,1), intArrayOf(0,1, 1,0), intArrayOf(0,0, 1,1, 2,2), intArrayOf(0,2, 1,1, 2,0)
        )
        raw.map { a -> prep((0 until a.size / 2).map { Pair(a[2 * it], a[2 * it + 1]) }) }
    }

    private fun seedOf(B: IntArray, list: List<P>): Long {
        var s = 17L
        for (r in B) s = s * 31 + r
        for (p in list) { for (m in p.m) s = s * 31 + m; s = s * 31 + p.h * 7 + p.w }
        return s
    }

    /**
     * Devuelve pasos [indicePieza, fila, columna, líneasLimpiadas] en el orden a jugar.
     * 1) Busca las mejores jugadas con las piezas actuales (todos los órdenes y lugares).
     * 2) Entre las mejores, imagina 8 próximos turnos al azar para cada una y se queda con la que
     *    mejor sobrevive: así deja espacio para piezas grandes y mantiene la racha de combos.
     */
    fun solve(B: IntArray, list: List<P>): List<IntArray> {
        require(B.size == 8 && B.all { it in 0..255 } && list.size <= 3)
        if (list.isEmpty()) return emptyList()
        val t0 = System.nanoTime()
        val main = SolverSearch(20, 12, t0 + 2_000_000_000L)
        main.run(B, list)
        val top = main.leaves.sortedByDescending { it.score }
        if (top.isEmpty()) return emptyList()
        val maxN = top.maxOf { it.moves.size }
        val cands = top.filter { it.moves.size == maxN }
        if (cands.size < 2 || maxN < list.size) return cands[0].moves
        val seed = seedOf(B, list)
        val deadline = t0 + 3_000_000_000L
        val cheap = SolverSearch(5, 1, deadline)
        var pick = cands[0]; var bestTotal = Long.MIN_VALUE
        for (leaf in cands) {
            if (Thread.currentThread().isInterrupted) break
            if (leaf !== cands[0] && System.nanoTime() > deadline) break
            val rnd = java.util.Random(seed)
            var fut = 0L; var complete = true
            for (t in 0 until 8) {
                val trio = listOf(LIB[rnd.nextInt(LIB.size)], LIB[rnd.nextInt(LIB.size)], LIB[rnd.nextInt(LIB.size)])
                cheap.run(leaf.board, trio)
                if (cheap.aborted) { complete = false; break }
                fut += cheap.best()
            }
            if (!complete) break
            val total = leaf.score.toLong() * 8 + fut
            if (total > bestTotal) { bestTotal = total; pick = leaf }
        }
        return pick.moves
    }
}

internal class SolverLeaf(val score: Int, val moves: List<IntArray>, val board: IntArray)

/** Búsqueda por haz: prueba todos los órdenes y se queda con los mejores lugares de cada pieza. Sin crear objetos en el camino caliente. */
internal class SolverSearch(private val beam: Int, private val keep: Int, private val deadline: Long) {
    var list: List<Solver.P> = emptyList()
    val leaves = ArrayList<SolverLeaf>()
    var aborted = false
    private var minScore = Int.MIN_VALUE
    private val cb = Array(3) { Array(64) { IntArray(8) } }
    private val cs = Array(3) { IntArray(64) }
    private val cr = Array(3) { IntArray(64) }
    private val cc = Array(3) { IntArray(64) }
    private val ck = Array(3) { IntArray(64) }
    private val ordr = Array(3) { IntArray(64) }
    private val pIdx = IntArray(3); private val pR = IntArray(3); private val pC = IntArray(3); private val pK = IntArray(3)
    private val tmp = IntArray(8)

    fun run(board: IntArray, pieces: List<Solver.P>) {
        list = pieces; leaves.clear(); minScore = Int.MIN_VALUE; aborted = false
        go(board, (1 shl pieces.size) - 1, 0, 0, 0, 0)
    }

    fun best(): Int {
        if (leaves.isEmpty()) return 0
        var m = Int.MIN_VALUE
        for (l in leaves) if (l.score > m) m = l.score
        return m
    }

    private fun pathMoves(d: Int): ArrayList<IntArray> {
        val l = ArrayList<IntArray>()
        for (x in 0 until d) l.add(intArrayOf(pIdx[x], pR[x], pC[x], pK[x]))
        return l
    }

    private fun qualifies(score: Int) = leaves.size < keep || score > minScore

    private fun recomputeMin() {
        var m = Int.MAX_VALUE
        for (l in leaves) if (l.score < m) m = l.score
        minScore = m
    }

    private fun add(score: Int, moves: List<IntArray>, board: IntArray) {
        for (idx in leaves.indices) {
            val o = leaves[idx]
            if (o.moves.size == moves.size && o.board.contentEquals(board)) {
                if (score > o.score) { leaves[idx] = SolverLeaf(score, moves, board.copyOf()); recomputeMin() }
                return
            }
        }
        val leaf = SolverLeaf(score, moves, board.copyOf())
        if (leaves.size < keep) leaves.add(leaf)
        else {
            var mi = 0
            for (i in 1 until leaves.size) if (leaves[i].score < leaves[mi].score) mi = i
            leaves[mi] = leaf
        }
        recomputeMin()
    }

    private fun go(board: IntArray, rem: Int, d: Int, k: Int, kq: Int, streak: Int) {
        if (aborted) return
        if (Thread.currentThread().isInterrupted || System.nanoTime() > deadline) { aborted = true; return }
        val score = d * 100000 + Solver.evaluate(board, k, kq, streak)
        if (qualifies(score)) add(score, pathMoves(d), board)
        for (i in list.indices) {
            if (((rem shr i) and 1) == 0) continue
            val p = list[i]
            val last = (rem and (rem - 1)) == 0
            var nc = 0
            for (r in 0..8 - p.h) for (c in 0..8 - p.w) {
                val kk = Solver.putInto(board, p, r, c, if (last) tmp else cb[d][nc])
                if (kk < 0) continue
                if (last) {
                    val s2 = (d + 1) * 100000 + Solver.evaluate(tmp, k + kk, kq + kk * kk, streak + (if (kk > 0) 1 else 0))
                    if (qualifies(s2)) {
                        val mv = pathMoves(d)
                        mv.add(intArrayOf(i, r, c, kk))
                        add(s2, mv, tmp)
                    }
                } else {
                    cr[d][nc] = r; cc[d][nc] = c; ck[d][nc] = kk
                    cs[d][nc] = Solver.evaluate(cb[d][nc], kk, kk * kk, if (kk > 0) 1 else 0)
                    nc++
                }
            }
            if (last) continue
            val o = ordr[d]
            for (t in 0 until nc) o[t] = t
            val take = minOf(beam, nc)
            for (t in 0 until take) {
                var bi = t
                for (u in t + 1 until nc) if (cs[d][o[u]] > cs[d][o[bi]]) bi = u
                val sw = o[t]; o[t] = o[bi]; o[bi] = sw
                val j = o[t]
                pIdx[d] = i; pR[d] = cr[d][j]; pC[d] = cc[d][j]; pK[d] = ck[d][j]
                go(cb[d][j], rem and (1 shl i).inv(), d + 1, k + ck[d][j], kq + ck[d][j] * ck[d][j], streak + (if (ck[d][j] > 0) 1 else 0))
                if (aborted) return
            }
        }
    }
}
