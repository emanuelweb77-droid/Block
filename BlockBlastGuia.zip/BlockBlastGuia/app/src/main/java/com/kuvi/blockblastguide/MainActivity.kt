package com.kuvi.blockblastguide

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val t = TextView(this).apply {
            text = "Block Blast Guía\n\n1) Toca Iniciar y da el permiso de mostrar sobre otras apps.\n2) Toca Iniciar otra vez y acepta compartir pantalla.\n3) Abre Block Blast con el tablero a la vista y toca Calibrar (se calibra solo y avisa con un mensaje). Luego toca Jugada en cada turno."
            textSize = 16f
            setPadding(40, 60, 40, 20)
        }
        val bt = Button(this).apply { text = "Iniciar"; setOnClickListener { start() } }
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(t); addView(bt) })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(m.createScreenCaptureIntent(), 7)
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 7 && c == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("code", c).putExtra("data", d))
            moveTaskToBack(true)
        }
    }
}
