package com.kuvi.blockblastguide

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    companion object {
        private var current=java.lang.ref.WeakReference<MainActivity>(null)
        fun closeTask() { current.get()?.finishAndRemoveTask() }
    }
    override fun onDestroy() {
        if(current.get()===this) current.clear()
        super.onDestroy()
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        current=java.lang.ref.WeakReference(this)
        val t = TextView(this).apply {
            text = "Block Blast Guía\n\n1) Toca Iniciar y permite mostrar sobre otras apps.\n2) Toca Iniciar otra vez y comparte TODA la pantalla.\n3) Abre Block Blast y mueve el menú fuera del tablero y las piezas. Arrastra el título para moverlo o tócalo para plegarlo.\n4) Toca Auto calibrar y espera que la barra se complete.\n5) Activa Auto marcar. Se indica UNA pieza por vez: el círculo identifica la pieza y los bordes de color su destino. Colócala y espera la siguiente marca.\n\nToca Auto marcar otra vez para pausar. Para cerrar completamente, toca × en el menú. También puedes usar Detener en la notificación.\n\nCalibra con al menos cuatro casillas vacías y el tablero quieto. La guía ajusta el fondo si cambian los colores. Mantén la misma orientación y recalibra si cambia la posición del tablero."
            textSize = 16f
            setPadding(40, 60, 40, 20)
        }
        val bt = Button(this).apply { text = "Iniciar"; setOnClickListener { start() } }
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(t); addView(bt) })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(m.createScreenCaptureIntent(), 7)
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 7 && c == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("code", c).putExtra("data", d))
            moveTaskToBack(true)
        }
    }
}
