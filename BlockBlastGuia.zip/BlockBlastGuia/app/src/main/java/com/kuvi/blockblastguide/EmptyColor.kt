package com.kuvi.blockblastguide

/** Dark empty-cell colour learned once during calibration, independent of saturation. */
object EmptyColor {
    private fun red(c:Int)=(c ushr 16) and 255
    private fun green(c:Int)=(c ushr 8) and 255
    private fun blue(c:Int)=c and 255
    fun distance(a:Int,b:Int):Double {
        val r=red(a)-red(b); val g=green(a)-green(b); val bl=blue(a)-blue(b)
        return kotlin.math.sqrt((r*r+g*g+bl*bl).toDouble())
    }
    fun consensus(colors:List<Int>):Int? {
        if(colors.size<4) return null
        val seed=colors.maxByOrNull { c -> colors.count { distance(c,it)<20 } } ?: return null
        val group=colors.filter { distance(it,seed)<20 }
        if(group.size<4 || group.size*5<colors.size*3) return null
        return (255 shl 24) or ((group.sumOf { red(it) }/group.size) shl 16) or
            ((group.sumOf { green(it) }/group.size) shl 8) or (group.sumOf { blue(it) }/group.size)
    }
    fun choose(colors:List<Int>):Int? {
        // Violet empty cells in the reported screenshot have saturation ~0.80.
        // Saturation cannot distinguish those empty cells from occupied cells.
        val candidates=colors.filter { maxOf(red(it),green(it),blue(it))/255f in .07f.. .57f }
        val clustered=candidates.filter { c -> candidates.count { distance(it,c)<16 }>=4 }
        return clustered.minByOrNull { red(it)*.2126+green(it)*.7152+blue(it)*.0722 }
    }
}
