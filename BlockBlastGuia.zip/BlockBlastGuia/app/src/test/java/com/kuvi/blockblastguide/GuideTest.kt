package com.kuvi.blockblastguide

import org.junit.Assert.*
import org.junit.Test
import java.util.Random

class GuideTest {
    @Test fun themeChangeNeedsRepeatedEmptyCellEvidenceAndResumes() {
        val old=0xFF201152.toInt(); val green=0xFF5F775F.toInt()
        val tracker=ThemeTracker(); tracker.reset(old)
        val newSamples=List(20) { green }+List(4) { 0xFFBB7733.toInt() }
        assertFalse(tracker.observe(newSamples,0))
        assertFalse(tracker.observe(newSamples,120))
        assertEquals(old,tracker.reference)
        assertTrue(tracker.observe(newSamples,240))
        assertEquals(green,tracker.reference)
        assertTrue(tracker.observe(newSamples,360))
        assertFalse(tracker.observe(List(20) { old },500))
        assertFalse(tracker.observe(List(20) { old },620))
        assertTrue(tracker.observe(List(20) { old },740))
        assertEquals(old,tracker.reference)
    }
    @Test fun oneFlashDoesNotReplaceTheBackground() {
        val old=0xFF201152.toInt(); val tracker=ThemeTracker(); tracker.reset(old)
        assertFalse(tracker.observe(List(20) { 0xFFEEDDCC.toInt() },0))
        assertTrue(tracker.observe(List(20) { old },120))
        assertEquals(old,tracker.reference)
    }
    @Test fun fillingSomeEmptyCellsDoesNotChangeTheTheme() {
        val old=0xFF201152.toInt(); val tracker=ThemeTracker(); tracker.reset(old)
        assertTrue(tracker.observe(List(20) { old }+List(5) { 0xFFFFCC22.toInt() },120))
        assertEquals(old,tracker.reference)
    }

    @Test fun diagonalPieceIsLegalWithoutEdgeConnection() {
        val diagonal=Solver.prep(listOf(0 to 0,1 to 1))
        val board=IntArray(8)
        val plan=Solver.solve(board,listOf(diagonal))
        assertEquals(1,plan.size)
        val m=plan.first()
        assertNotNull(Solver.put(board,diagonal,m[1],m[2]))
        board[m[1]]=1 shl m[2]
        assertNull(Solver.put(board,diagonal,m[1],m[2]))
    }

    @Test fun violetEmptyCellsAreAcceptedEvenWithHighSaturation() {
        val violet=0xFF201152.toInt()
        // RGB samples from the reported screenshot: dark violet, yellow and orange.
        val colors=List(4) { violet }+List(40) { 0xFFA78B10.toInt() }+List(20) { 0xFFB05332.toInt() }
        assertEquals(violet,EmptyColor.choose(colors))
        assertTrue(EmptyColor.distance(violet,0xFF1F1051.toInt())<27)
        assertTrue(EmptyColor.distance(violet,0xFFA78B10.toInt())>27)
    }
    @Test fun noDarkEmptyReferenceDoesNotInventOne() {
        assertNull(EmptyColor.choose(List(64) { 0xFFA78B10.toInt() }))
        assertNull(EmptyColor.choose(List(3) { 0xFF201152.toInt() }))
    }

    @Test fun rejectsOccupiedCellsAndOutOfBounds() {
        val piece=Solver.prep(listOf(0 to 0, 0 to 1))
        val board=IntArray(8); board[2]=1 shl 3
        assertNull(Solver.put(board,piece,2,2))
        assertNull(Solver.put(board,piece,2,3))
        assertNull(Solver.put(board,piece,-1,0))
        assertNull(Solver.put(board,piece,0,7))
        assertNotNull(Solver.put(board,piece,2,4))
        assertEquals(8,board[2])
    }
    @Test fun clearsRowAndColumnSimultaneously() {
        val board=IntArray(8) { 1 }; board[0]=254
        val result=Solver.put(board,Solver.prep(listOf(0 to 0)),0,0)!!
        assertEquals(2,result.second)
        assertTrue(result.first.all { it==0 })
    }
    @Test fun subsequentMovesMayUseSpaceThatIsCurrentlyOccupied() {
        val board=intArrayOf(254,0,0,0,0,0,0,0)
        val after=Solver.put(board,Solver.prep(listOf(0 to 0)),0,0)!!.first
        val bar=Solver.prep((0..4).map { 0 to it })
        assertNull(Solver.put(board,bar,0,0))
        assertNotNull(Solver.put(after,bar,0,0))
    }
    @Test fun completePlansAreLegalAndDoNotMutateInput() {
        val random=Random(12)
        val pieces=listOf(Solver.prep(listOf(0 to 0,0 to 1,1 to 0)),Solver.prep(listOf(0 to 0,1 to 0,2 to 0)),Solver.prep(listOf(0 to 0,0 to 1,1 to 0,1 to 1)))
        repeat(25) {
            val board=IntArray(8) { random.nextInt(256) }; val original=board.copyOf()
            val plan=Solver.solve(board,pieces); var current=board
            val used=mutableSetOf<Int>()
            for(move in plan) {
                assertTrue(used.add(move[0]))
                val result=Solver.put(current,pieces[move[0]],move[1],move[2])
                assertNotNull(result); current=result!!.first
            }
            assertArrayEquals(original,board)
        }
    }
    @Test fun emptyBoardProducesThreeMovesWithinBudget() {
        val start=System.nanoTime()
        val piece=Solver.prep(listOf(0 to 0))
        assertEquals(3,Solver.solve(IntArray(8),listOf(piece,piece,piece)).size)
        assertTrue((System.nanoTime()-start)/1_000_000<10000)
    }
    @Test fun flickeringReadingsNeverBecomeStable() {
        val gate=StableGate()
        repeat(20) { assertFalse(gate.offer(if(it%2==0) "A" else "B",it*300L)) }
        assertFalse(gate.offer("C",6000))
        assertFalse(gate.offer("C",6060))
        assertTrue(gate.offer("C",6120))
        assertFalse(gate.offer("D",6900))
        gate.reset(); assertFalse(gate.offer("C",7200))
    }

    @Test fun lookaheadPlansAreLegalAndBounded() {
        val random=Random(7)
        val shapes=listOf(listOf(0 to 0,0 to 1,0 to 2),listOf(0 to 0,1 to 0,1 to 1),listOf(0 to 0,0 to 1,1 to 0,1 to 1))
        repeat(10) {
            val board=IntArray(8) { if(random.nextInt(3)==0) random.nextInt(256) else 0 }
            val pieces=shapes.map { Solver.prep(it) }
            val start=System.nanoTime()
            val plan=Solver.solve(board,pieces)
            assertTrue((System.nanoTime()-start)/1_000_000<5000)
            var current=board; val used=mutableSetOf<Int>()
            for(m in plan) {
                assertTrue(used.add(m[0]))
                val r=Solver.put(current,pieces[m[0]],m[1],m[2]); assertNotNull(r); current=r!!.first
            }
        }
    }
    @Test fun sameScreenGivesSamePlan() {
        val board=intArrayOf(0,0,0,0,0,0,0,0).also { it[7]=0b01111111; it[6]=0b00111100 }
        val pieces=listOf(Solver.prep(listOf(0 to 0)),Solver.prep(listOf(0 to 0,0 to 1,0 to 2)),Solver.prep(listOf(0 to 0,0 to 1,1 to 0,1 to 1)))
        val a=Solver.solve(board,pieces); val b=Solver.solve(board,pieces)
        assertEquals(a.map { it.toList() },b.map { it.toList() })
    }
}
