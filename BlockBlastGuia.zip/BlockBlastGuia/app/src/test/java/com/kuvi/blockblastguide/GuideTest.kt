package com.kuvi.blockblastguide

import org.junit.Assert.*
import org.junit.Test
import java.util.Random

class GuideTest {
    @Test fun rejectsOccupiedCellsAndOutOfBounds() {
        val piece=Solver.prep(listOf(0 to 0, 0 to 1))
        val board=IntArray(8); board[2]=1 shl 3
        assertNull(Solver.put(board,piece,2,2))
        assertNull(Solver.put(board,piece,2,3))
        assertNull(Solver.put(board,piece,-1,0))
        assertNull(Solver.put(board,piece,0,7))
        assertNotNull(Solver.put(board,piece,2,4))
        assertEquals(8,board[2])
    }
    @Test fun clearsRowAndColumnSimultaneously() {
        val board=IntArray(8) { 1 }; board[0]=254
        val result=Solver.put(board,Solver.prep(listOf(0 to 0)),0,0)!!
        assertEquals(2,result.second)
        assertTrue(result.first.all { it==0 })
    }
    @Test fun subsequentMovesMayUseSpaceThatIsCurrentlyOccupied() {
        val board=intArrayOf(254,0,0,0,0,0,0,0)
        val after=Solver.put(board,Solver.prep(listOf(0 to 0)),0,0)!!.first
        val bar=Solver.prep((0..4).map { 0 to it })
        assertNull(Solver.put(board,bar,0,0))
        assertNotNull(Solver.put(after,bar,0,0))
    }
    @Test fun completePlansAreLegalAndDoNotMutateInput() {
        val random=Random(12)
        val pieces=listOf(Solver.prep(listOf(0 to 0,0 to 1,1 to 0)),Solver.prep(listOf(0 to 0,1 to 0,2 to 0)),Solver.prep(listOf(0 to 0,0 to 1,1 to 0,1 to 1)))
        repeat(25) {
            val board=IntArray(8) { random.nextInt(256) }; val original=board.copyOf()
            val plan=Solver.solve(board,pieces); var current=board
            val used=mutableSetOf<Int>()
            for(move in plan) {
                assertTrue(used.add(move[0]))
                val result=Solver.put(current,pieces[move[0]],move[1],move[2])
                assertNotNull(result); current=result!!.first
            }
            assertArrayEquals(original,board)
        }
    }
    @Test fun emptyBoardProducesThreeMovesWithinBudget() {
        val start=System.nanoTime()
        val piece=Solver.prep(listOf(0 to 0))
        assertEquals(3,Solver.solve(IntArray(8),listOf(piece,piece,piece)).size)
        assertTrue((System.nanoTime()-start)/1_000_000<10000)
    }
    @Test fun flickeringReadingsNeverBecomeStable() {
        val gate=StableGate()
        repeat(20) { assertFalse(gate.offer(if(it%2==0) "A" else "B",it*300L)) }
        assertFalse(gate.offer("C",6000))
        assertFalse(gate.offer("C",6300))
        assertTrue(gate.offer("C",6600))
        assertFalse(gate.offer("D",6900))
        gate.reset(); assertFalse(gate.offer("C",7200))
    }
}
